import { supabase } from "@/lib/supabaseClient";
import { mapAlert, type AlertRow } from "@/lib/mappers";
import type { Alert, AlertStatus, Severity } from "@/types";

export interface AlertFilters {
  severity?: Severity;
  status?: AlertStatus;
}

const ALERT_SELECT = "*, product:products(*), order:orders(id)";

export const alertsApi = {
  list: async (filters: AlertFilters = {}): Promise<Alert[]> => {
    let query = supabase.from("alerts").select(ALERT_SELECT).order("detected_at", { ascending: false });
    if (filters.severity) query = query.eq("severity", filters.severity);
    if (filters.status) query = query.eq("status", filters.status);

    const { data, error } = await query;
    if (error) throw error;
    return ((data as unknown as AlertRow[]) ?? []).map(mapAlert);
  },

  update: async (id: string, payload: { status: AlertStatus }): Promise<Alert> => {
    const { data, error } = await supabase
      .from("alerts")
      .update({ status: payload.status })
      .eq("id", id)
      .select(ALERT_SELECT)
      .single();
    if (error) throw error;
    return mapAlert(data as unknown as AlertRow);
  },
};
