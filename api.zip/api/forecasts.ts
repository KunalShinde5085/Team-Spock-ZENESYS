import { supabase } from "@/lib/supabaseClient";
import { pickProduct, type ProductRow } from "@/lib/mappers";
import type { Forecast, ForecastHorizon, ForecastPoint, ForecastSummary } from "@/types";

const FORECAST_SELECT = "*, product:products(*)";

interface ForecastRow {
  id: string;
  horizon: ForecastHorizon;
  series: ForecastPoint[];
  summary: ForecastSummary;
  product: ProductRow;
}

function mapForecast(row: ForecastRow): Forecast {
  return {
    product: pickProduct(row.product),
    horizon: row.horizon,
    series: row.series ?? [],
    summary: row.summary,
  };
}

export const forecastsApi = {
  list: async (horizon: ForecastHorizon = 30): Promise<Forecast[]> => {
    const { data, error } = await supabase.from("forecasts").select(FORECAST_SELECT).eq("horizon", horizon);
    if (error) throw error;
    return ((data as unknown as ForecastRow[]) ?? []).map(mapForecast);
  },

  getByProduct: async (productId: string, horizon: ForecastHorizon = 30): Promise<Forecast> => {
    const { data, error } = await supabase
      .from("forecasts")
      .select(FORECAST_SELECT)
      .eq("product_id", productId)
      .eq("horizon", horizon)
      .single();
    if (error) throw error;
    return mapForecast(data as unknown as ForecastRow);
  },
};
