import { supabase } from "@/lib/supabaseClient";
import {
  computeStockStatus,
  mapProduct,
  type ProductRow,
} from "@/lib/mappers";
import type { InventoryDetail, InventoryTransaction, Order, Product } from "@/types";

export interface InventoryFilters {
  search?: string;
  category?: string;
  warehouse?: string;
  stockStatus?: string;
}

export const inventoryApi = {
  list: async (filters: InventoryFilters = {}): Promise<Product[]> => {
    let query = supabase.from("products").select("*").order("name", { ascending: true });
    if (filters.search) query = query.or(`name.ilike.%${filters.search}%,code.ilike.%${filters.search}%`);
    if (filters.category) query = query.eq("category", filters.category);
    if (filters.warehouse) query = query.eq("warehouse", filters.warehouse);

    const { data, error } = await query;
    if (error) throw error;

    let products = (data as ProductRow[]).map(mapProduct);
    if (filters.stockStatus) {
      products = products.filter((p) => p.stockStatus === filters.stockStatus);
    }
    return products;
  },

  getById: async (id: string): Promise<InventoryDetail> => {
    const { data: productRow, error: productError } = await supabase
      .from("products")
      .select("*")
      .eq("id", id)
      .single();
    if (productError) throw productError;
    const product = mapProduct(productRow as ProductRow);

    const { data: txnRows, error: txnError } = await supabase
      .from("inventory_transactions")
      .select("*")
      .eq("product_id", id)
      .order("timestamp", { ascending: false })
      .limit(10);
    if (txnError) throw txnError;

    const recentTransactions: InventoryTransaction[] = (txnRows ?? []).map((r) => ({
      id: r.id,
      type: r.type,
      quantity: r.quantity,
      reference: r.reference ?? undefined,
      timestamp: r.timestamp,
    }));

    // Stock trend: derive a running total from transactions, oldest first.
    const { data: trendRows, error: trendError } = await supabase
      .from("inventory_transactions")
      .select("*")
      .eq("product_id", id)
      .order("timestamp", { ascending: true });
    if (trendError) throw trendError;

    let running = product.currentStock;
    const deltas = (trendRows ?? []).map((r) => {
      const signed = r.type === "Outbound" || r.type === "Reserved" ? -r.quantity : r.quantity;
      return { date: r.timestamp as string, delta: signed };
    });
    // Walk backwards from current stock to reconstruct a plausible trend.
    const reversed = [...deltas].reverse();
    const stockTrend = reversed
      .map((d) => {
        const point = { date: d.date, stock: running };
        running -= d.delta;
        return point;
      })
      .reverse();

    const { data: orderRows, error: orderError } = await supabase
      .from("orders")
      .select("id, status, quantity")
      .eq("product_id", id)
      .order("order_date", { ascending: false })
      .limit(10);
    if (orderError) throw orderError;
    const relatedOrders: Pick<Order, "id" | "status" | "quantity">[] = (orderRows ?? []).map((r) => ({
      id: r.id,
      status: r.status,
      quantity: r.quantity,
    }));

    const { data: forecastRow } = await supabase
      .from("forecasts")
      .select("summary")
      .eq("product_id", id)
      .eq("horizon", 30)
      .maybeSingle();
    const demandForecastUnits = (forecastRow?.summary as { predictedDemand?: number } | undefined)?.predictedDemand ?? 0;

    const { data: recRow } = await supabase
      .from("recommendations")
      .select("action, reason")
      .eq("product_id", id)
      .eq("status", "Pending")
      .order("created_at", { ascending: false })
      .maybeSingle();

    return {
      ...product,
      stockTrend,
      recentTransactions,
      relatedOrders,
      demandForecastUnits,
      recommendation: recRow ? { message: recRow.reason ?? "", action: recRow.action } : undefined,
    };
  },

  update: async (id: string, payload: Partial<Product>): Promise<Product> => {
    const patch: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (payload.currentStock !== undefined) patch.current_stock = payload.currentStock;
    if (payload.reservedStock !== undefined) patch.reserved_stock = payload.reservedStock;
    if (payload.damagedStock !== undefined) patch.damaged_stock = payload.damagedStock;
    if (payload.safetyStock !== undefined) patch.safety_stock = payload.safetyStock;
    if (payload.reorderLevel !== undefined) patch.reorder_level = payload.reorderLevel;
    if (payload.leadTimeDays !== undefined) patch.lead_time_days = payload.leadTimeDays;
    if (payload.warehouse !== undefined) patch.warehouse = payload.warehouse;

    const { data, error } = await supabase.from("products").update(patch).eq("id", id).select("*").single();
    if (error) throw error;
    return mapProduct(data as ProductRow);
  },
};

// re-export for callers that only need the pure status calc
export { computeStockStatus };
