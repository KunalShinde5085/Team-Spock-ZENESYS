import { supabase } from "@/lib/supabaseClient";
import { mapProduction, type ProductionRow } from "@/lib/mappers";
import type { ProductionRecord } from "@/types";

export interface ProductionFilters {
  search?: string;
  status?: string;
  dateFrom?: string;
  dateTo?: string;
}

export interface CreateProductionPayload {
  productId: string;
  date: string;
  planned: number;
}

const PRODUCTION_SELECT = "*, product:products(*)";

export const productionApi = {
  list: async (filters: ProductionFilters = {}): Promise<ProductionRecord[]> => {
    let query = supabase.from("production").select(PRODUCTION_SELECT).order("date", { ascending: false });
    if (filters.status) query = query.eq("status", filters.status);
    if (filters.dateFrom) query = query.gte("date", filters.dateFrom);
    if (filters.dateTo) query = query.lte("date", filters.dateTo);

    const { data, error } = await query;
    if (error) throw error;

    let rows = (data as unknown as ProductionRow[]) ?? [];
    if (filters.search) {
      const q = filters.search.toLowerCase();
      rows = rows.filter((r) => r.product?.name?.toLowerCase().includes(q) || r.product?.code?.toLowerCase().includes(q));
    }
    return rows.map(mapProduction);
  },

  getById: async (id: string): Promise<ProductionRecord> => {
    const { data, error } = await supabase.from("production").select(PRODUCTION_SELECT).eq("id", id).single();
    if (error) throw error;
    return mapProduction(data as unknown as ProductionRow);
  },

  create: async (payload: CreateProductionPayload): Promise<ProductionRecord> => {
    const { data, error } = await supabase
      .from("production")
      .insert({
        product_id: payload.productId,
        date: payload.date,
        planned: payload.planned,
        produced: 0,
        rejected: 0,
        status: "Scheduled",
      })
      .select(PRODUCTION_SELECT)
      .single();
    if (error) throw error;
    return mapProduction(data as unknown as ProductionRow);
  },
};
