import { supabase } from "@/lib/supabaseClient";
import { mapProduct, type ProductRow } from "@/lib/mappers";
import type { Product } from "@/types";

export const productsApi = {
  list: async (search?: string): Promise<Product[]> => {
    let query = supabase.from("products").select("*").order("name", { ascending: true });
    if (search) {
      query = query.or(`name.ilike.%${search}%,code.ilike.%${search}%`);
    }
    const { data, error } = await query;
    if (error) throw error;
    return (data as ProductRow[]).map(mapProduct);
  },

  getById: async (id: string): Promise<Product> => {
    const { data, error } = await supabase.from("products").select("*").eq("id", id).single();
    if (error) throw error;
    return mapProduct(data as ProductRow);
  },
};
