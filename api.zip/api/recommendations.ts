import { supabase } from "@/lib/supabaseClient";
import { mapRecommendation, type RecommendationRow } from "@/lib/mappers";
import type { Recommendation, RecommendationStatus } from "@/types";

const RECOMMENDATION_SELECT = "*, product:products(*)";

export const recommendationsApi = {
  list: async (status?: RecommendationStatus): Promise<Recommendation[]> => {
    let query = supabase.from("recommendations").select(RECOMMENDATION_SELECT).order("created_at", { ascending: false });
    if (status) query = query.eq("status", status);
    const { data, error } = await query;
    if (error) throw error;
    return ((data as unknown as RecommendationRow[]) ?? []).map(mapRecommendation);
  },

  update: async (id: string, payload: { status: RecommendationStatus }): Promise<Recommendation> => {
    const { data, error } = await supabase
      .from("recommendations")
      .update({ status: payload.status })
      .eq("id", id)
      .select(RECOMMENDATION_SELECT)
      .single();
    if (error) throw error;
    return mapRecommendation(data as unknown as RecommendationRow);
  },
};
