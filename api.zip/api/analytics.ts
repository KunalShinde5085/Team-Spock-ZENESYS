import { supabase } from "@/lib/supabaseClient";

export interface AnalyticsResponse {
  monthlyDemandTrend: { period: string; demand: number }[];
  topProducts: { name: string; demand: number }[];
  fulfillmentPerformance: { period: string; onTime: number; delayed: number }[];
  inventoryHealth: { status: string; count: number }[];
  productionEfficiency: { period: string; efficiency: number }[];
  rejectionByProduct: { name: string; rate: number }[];
  forecastAccuracy: { period: string; accuracy: number }[];
  delayedOrdersTrend: { period: string; count: number }[];
}

function monthKey(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString("en-US", { month: "short", year: "2-digit" });
}

export const analyticsApi = {
  get: async (dateFrom?: string, dateTo?: string): Promise<AnalyticsResponse> => {
    let salesQuery = supabase.from("sales_history").select("*, product:products(name)");
    if (dateFrom) salesQuery = salesQuery.gte("date", dateFrom);
    if (dateTo) salesQuery = salesQuery.lte("date", dateTo);

    let ordersQuery = supabase.from("orders").select("status, order_date, required_date");
    if (dateFrom) ordersQuery = ordersQuery.gte("order_date", dateFrom);
    if (dateTo) ordersQuery = ordersQuery.lte("order_date", dateTo);

    let productionQuery = supabase.from("production").select("date, planned, produced, rejected, product:products(name)");
    if (dateFrom) productionQuery = productionQuery.gte("date", dateFrom);
    if (dateTo) productionQuery = productionQuery.lte("date", dateTo);

    const [sales, orders, production, inventory, forecasts] = await Promise.all([
      salesQuery,
      ordersQuery,
      productionQuery,
      supabase.from("products").select("current_stock, reserved_stock, damaged_stock, safety_stock, reorder_level"),
      supabase.from("forecasts").select("product_id, series"),
    ]);
    if (sales.error) throw sales.error;
    if (orders.error) throw orders.error;
    if (production.error) throw production.error;
    if (inventory.error) throw inventory.error;
    if (forecasts.error) throw forecasts.error;

    // Monthly demand trend + top products
    const demandByMonth = new Map<string, number>();
    const demandByProduct = new Map<string, number>();
    for (const row of sales.data ?? []) {
      const month = monthKey(row.date);
      demandByMonth.set(month, (demandByMonth.get(month) ?? 0) + row.quantity_sold);
      const name = (row.product as { name?: string } | null)?.name ?? "Unknown";
      demandByProduct.set(name, (demandByProduct.get(name) ?? 0) + row.quantity_sold);
    }
    const monthlyDemandTrend = Array.from(demandByMonth.entries()).map(([period, demand]) => ({ period, demand }));
    const topProducts = Array.from(demandByProduct.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([name, demand]) => ({ name, demand }));

    // Fulfillment performance: on-time vs delayed, grouped by month
    const fulfillmentByMonth = new Map<string, { onTime: number; delayed: number }>();
    for (const row of orders.data ?? []) {
      const month = monthKey(row.order_date);
      const entry = fulfillmentByMonth.get(month) ?? { onTime: 0, delayed: 0 };
      const isTerminal = row.status === "Delivered" || row.status === "Cancelled";
      const isLate = new Date(row.required_date) < new Date() && !isTerminal;
      if (isLate) entry.delayed += 1;
      else entry.onTime += 1;
      fulfillmentByMonth.set(month, entry);
    }
    const fulfillmentPerformance = Array.from(fulfillmentByMonth.entries()).map(([period, v]) => ({ period, ...v }));

    // Delayed orders trend (same underlying data, delayed counts only)
    const delayedOrdersTrend = fulfillmentPerformance.map((f) => ({ period: f.period, count: f.delayed }));

    // Inventory health distribution
    const healthCounts = new Map<string, number>();
    for (const row of inventory.data ?? []) {
      const available = row.current_stock - row.reserved_stock - row.damaged_stock;
      let status: string;
      if (available <= 0 || available < row.safety_stock) status = "Critical";
      else if (available < row.reorder_level) status = "Low";
      else if (available > row.reorder_level * 3) status = "Overstock";
      else status = "Healthy";
      healthCounts.set(status, (healthCounts.get(status) ?? 0) + 1);
    }
    const inventoryHealth = Array.from(healthCounts.entries()).map(([status, count]) => ({ status, count }));

    // Production efficiency + rejection rate
    const efficiencyByMonth = new Map<string, { produced: number; planned: number }>();
    const rejectionByProductMap = new Map<string, { rejected: number; produced: number }>();
    for (const row of production.data ?? []) {
      const month = monthKey(row.date);
      const eff = efficiencyByMonth.get(month) ?? { produced: 0, planned: 0 };
      eff.produced += row.produced;
      eff.planned += row.planned;
      efficiencyByMonth.set(month, eff);

      const name = (row.product as { name?: string } | null)?.name ?? "Unknown";
      const rej = rejectionByProductMap.get(name) ?? { rejected: 0, produced: 0 };
      rej.rejected += row.rejected;
      rej.produced += row.produced + row.rejected;
      rejectionByProductMap.set(name, rej);
    }
    const productionEfficiency = Array.from(efficiencyByMonth.entries()).map(([period, v]) => ({
      period,
      efficiency: v.planned > 0 ? Math.round((v.produced / v.planned) * 1000) / 10 : 0,
    }));
    const rejectionByProduct = Array.from(rejectionByProductMap.entries()).map(([name, v]) => ({
      name,
      rate: v.produced > 0 ? Math.round((v.rejected / v.produced) * 1000) / 10 : 0,
    }));

    // Forecast accuracy: compare forecast series historicalDemand vs forecastedDemand where both present
    const accuracyByPeriod = new Map<string, { diffPct: number; count: number }>();
    for (const row of forecasts.data ?? []) {
      const series = (row.series as { period: string; historicalDemand?: number; forecastedDemand?: number }[]) ?? [];
      for (const point of series) {
        if (point.historicalDemand && point.forecastedDemand) {
          const err = Math.abs(point.historicalDemand - point.forecastedDemand) / point.historicalDemand;
          const entry = accuracyByPeriod.get(point.period) ?? { diffPct: 0, count: 0 };
          entry.diffPct += 1 - err;
          entry.count += 1;
          accuracyByPeriod.set(point.period, entry);
        }
      }
    }
    const forecastAccuracy = Array.from(accuracyByPeriod.entries()).map(([period, v]) => ({
      period,
      accuracy: v.count > 0 ? Math.round((v.diffPct / v.count) * 1000) / 10 : 0,
    }));

    return {
      monthlyDemandTrend,
      topProducts,
      fulfillmentPerformance,
      inventoryHealth,
      productionEfficiency,
      rejectionByProduct,
      forecastAccuracy,
      delayedOrdersTrend,
    };
  },
};
