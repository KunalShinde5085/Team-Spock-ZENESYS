import { supabase } from "@/lib/supabaseClient";
import {
  computeAvailableStock,
  mapOrder,
  mapOrderDetail,
  type OrderRow,
  type OrderStatusHistoryRow,
  type ProductRow,
} from "@/lib/mappers";
import type {
  CreateOrderPayload,
  Order,
  OrderDetail,
  OrderFilters,
  PaginatedResponse,
  UpdateOrderPayload,
} from "@/types";

const ORDER_SELECT = "*, customer:customers(*), product:products(*)";

export const ordersApi = {
  list: async (filters: OrderFilters = {}): Promise<PaginatedResponse<Order>> => {
    const page = filters.page ?? 1;
    const pageSize = filters.pageSize ?? 20;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from("orders")
      .select(ORDER_SELECT, { count: "exact" })
      .order("order_date", { ascending: false })
      .range(from, to);

    if (filters.status) query = query.eq("status", filters.status);
    if (filters.priority) query = query.eq("priority", filters.priority);
    if (filters.customerId) query = query.eq("customer_id", filters.customerId);
    if (filters.productId) query = query.eq("product_id", filters.productId);
    if (filters.dateFrom) query = query.gte("order_date", filters.dateFrom);
    if (filters.dateTo) query = query.lte("order_date", filters.dateTo);

    const { data, error, count } = await query;
    if (error) throw error;

    let rows = (data as unknown as OrderRow[]) ?? [];
    // Client-side search across customer name / product name / code — Supabase
    // can't easily filter on embedded-table columns in a single .or() call.
    if (filters.search) {
      const q = filters.search.toLowerCase();
      rows = rows.filter(
        (r) =>
          r.customer?.name?.toLowerCase().includes(q) ||
          r.product?.name?.toLowerCase().includes(q) ||
          r.product?.code?.toLowerCase().includes(q) ||
          r.id.toLowerCase().includes(q)
      );
    }

    return {
      data: rows.map(mapOrder),
      total: count ?? rows.length,
      page,
      pageSize,
    };
  },

  getById: async (id: string): Promise<OrderDetail> => {
    const { data, error } = await supabase.from("orders").select(ORDER_SELECT).eq("id", id).single();
    if (error) throw error;

    const { data: historyData, error: historyError } = await supabase
      .from("order_status_history")
      .select("*")
      .eq("order_id", id)
      .order("timestamp", { ascending: true });
    if (historyError) throw historyError;

    return mapOrderDetail(data as unknown as OrderRow, (historyData as OrderStatusHistoryRow[]) ?? []);
  },

  create: async (payload: CreateOrderPayload): Promise<Order> => {
    const { data: product, error: productError } = await supabase
      .from("products")
      .select("*")
      .eq("id", payload.productId)
      .single();
    if (productError) throw productError;

    const { data: inserted, error: insertError } = await supabase
      .from("orders")
      .insert({
        customer_id: payload.customerId,
        product_id: payload.productId,
        quantity: payload.quantity,
        required_date: payload.requiredDate,
        priority: payload.priority,
        notes: payload.notes,
        status: "Pending",
      })
      .select(ORDER_SELECT)
      .single();
    if (insertError) throw insertError;

    await supabase.from("order_status_history").insert({
      order_id: inserted.id,
      label: "Pending",
      status: "Pending",
    });

    // Reserve stock for the order.
    await supabase
      .from("products")
      .update({ reserved_stock: (product as ProductRow).reserved_stock + payload.quantity })
      .eq("id", payload.productId);

    // Raise a shortage alert if there isn't enough available stock.
    const available = computeAvailableStock(product as ProductRow);
    if (available < payload.quantity) {
      await supabase.from("alerts").insert({
        severity: "High",
        type: "Stock Shortage",
        title: `Stock shortage for ${(product as ProductRow).name}`,
        product_id: payload.productId,
        order_id: inserted.id,
        status: "Open",
        description: `Order requires ${payload.quantity} units but only ${available} are available.`,
      });
    }

    return mapOrder(inserted as unknown as OrderRow);
  },

  update: async (id: string, payload: UpdateOrderPayload): Promise<Order> => {
    const patch: Record<string, unknown> = {};
    if (payload.customerId) patch.customer_id = payload.customerId;
    if (payload.productId) patch.product_id = payload.productId;
    if (payload.quantity !== undefined) patch.quantity = payload.quantity;
    if (payload.requiredDate) patch.required_date = payload.requiredDate;
    if (payload.priority) patch.priority = payload.priority;
    if (payload.notes !== undefined) patch.notes = payload.notes;
    if (payload.status) patch.status = payload.status;

    const { data, error } = await supabase
      .from("orders")
      .update(patch)
      .eq("id", id)
      .select(ORDER_SELECT)
      .single();
    if (error) throw error;

    if (payload.status) {
      await supabase.from("order_status_history").insert({
        order_id: id,
        label: payload.status,
        status: payload.status,
      });
    }

    return mapOrder(data as unknown as OrderRow);
  },

  remove: async (id: string): Promise<void> => {
    const { error } = await supabase.from("orders").delete().eq("id", id);
    if (error) throw error;
  },
};
