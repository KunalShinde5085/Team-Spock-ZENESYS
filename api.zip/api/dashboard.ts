import { supabase } from "@/lib/supabaseClient";
import { computeAvailableStock, computeOrderRisk, computeStockStatus, type OrderRow, type ProductRow } from "@/lib/mappers";
import type { DashboardKpis, FulfillmentBreakdown, InventoryRiskBreakdown, OrderStatus, StockStatus } from "@/types";

const TERMINAL_STATUSES: OrderStatus[] = ["Delivered", "Cancelled"];

export const dashboardApi = {
  getKpis: async (): Promise<DashboardKpis> => {
    const [{ data: orders, error: ordersError }, { data: products, error: productsError }, { data: alerts, error: alertsError }, { data: forecasts, error: forecastsError }] =
      await Promise.all([
        supabase.from("orders").select("*, customer:customers(*), product:products(*)"),
        supabase.from("products").select("*"),
        supabase.from("alerts").select("id, severity, status").eq("status", "Open").eq("severity", "Critical"),
        supabase.from("forecasts").select("summary").eq("horizon", 30),
      ]);
    if (ordersError) throw ordersError;
    if (productsError) throw productsError;
    if (alertsError) throw alertsError;
    if (forecastsError) throw forecastsError;

    const orderRows = (orders as unknown as OrderRow[]) ?? [];
    const productRows = (products as ProductRow[]) ?? [];

    const activeOrders = orderRows.filter((o) => !TERMINAL_STATUSES.includes(o.status));
    const ordersAtRisk = activeOrders.filter((o) => {
      const risk = computeOrderRisk(o);
      return risk === "At Risk" || risk === "Delayed" || risk === "Stock Shortage";
    }).length;

    const now = new Date();
    const weekAgo = new Date(now);
    weekAgo.setDate(now.getDate() - 7);
    const twoWeeksAgo = new Date(now);
    twoWeeksAgo.setDate(now.getDate() - 14);
    const thisWeekCount = orderRows.filter((o) => new Date(o.order_date) >= weekAgo).length;
    const lastWeekCount = orderRows.filter((o) => new Date(o.order_date) >= twoWeeksAgo && new Date(o.order_date) < weekAgo).length;

    const inventoryValue = productRows.reduce(
      (sum, p) => sum + p.current_stock * (p.unit_cost ?? 0),
      0
    );
    const lowStockItems = productRows.filter((p) => {
      const available = computeAvailableStock(p);
      const status = computeStockStatus(available, p.safety_stock, p.reorder_level);
      return status === "Low" || status === "Critical";
    }).length;

    const forecastedDemand30d = (forecasts ?? []).reduce(
      (sum, f) => sum + ((f.summary as { predictedDemand?: number })?.predictedDemand ?? 0),
      0
    );

    return {
      activeOrders: activeOrders.length,
      activeOrdersDelta: thisWeekCount - lastWeekCount,
      ordersAtRisk,
      inventoryValue,
      lowStockItems,
      forecastedDemand30d,
      openCriticalAlerts: alerts?.length ?? 0,
    };
  },

  getFulfillmentBreakdown: async (): Promise<FulfillmentBreakdown[]> => {
    const { data, error } = await supabase.from("orders").select("status");
    if (error) throw error;
    const counts = new Map<OrderStatus, number>();
    for (const row of data ?? []) {
      const status = row.status as OrderStatus;
      counts.set(status, (counts.get(status) ?? 0) + 1);
    }
    return Array.from(counts.entries()).map(([status, count]) => ({ status, count }));
  },

  getInventoryRiskBreakdown: async (): Promise<InventoryRiskBreakdown[]> => {
    const { data, error } = await supabase.from("products").select("*");
    if (error) throw error;
    const counts = new Map<StockStatus, number>();
    for (const row of (data as ProductRow[]) ?? []) {
      const available = computeAvailableStock(row);
      const status = computeStockStatus(available, row.safety_stock, row.reorder_level);
      counts.set(status, (counts.get(status) ?? 0) + 1);
    }
    return Array.from(counts.entries()).map(([status, count]) => ({ status, count }));
  },

  getDemandVsInventory: async (): Promise<
    { period: string; historical?: number; forecast?: number; inventory?: number }[]
  > => {
    const { data: forecastRows, error: forecastError } = await supabase
      .from("forecasts")
      .select("series")
      .eq("horizon", 30);
    if (forecastError) throw forecastError;

    const { data: productRows, error: productError } = await supabase.from("products").select("current_stock");
    if (productError) throw productError;
    const totalInventory = (productRows ?? []).reduce((sum, p) => sum + (p.current_stock ?? 0), 0);

    const byPeriod = new Map<string, { historical: number; forecast: number }>();
    for (const row of forecastRows ?? []) {
      const series = (row.series as { period: string; historicalDemand?: number; forecastedDemand?: number }[]) ?? [];
      for (const point of series) {
        const entry = byPeriod.get(point.period) ?? { historical: 0, forecast: 0 };
        entry.historical += point.historicalDemand ?? 0;
        entry.forecast += point.forecastedDemand ?? 0;
        byPeriod.set(point.period, entry);
      }
    }

    const periods = Array.from(byPeriod.keys()).sort();
    return periods.map((period, i) => ({
      period,
      historical: byPeriod.get(period)!.historical || undefined,
      forecast: byPeriod.get(period)!.forecast || undefined,
      inventory: i === periods.length - 1 ? totalInventory : undefined,
    }));
  },
};
