import { createClient } from "@supabase/supabase-js";

export const SUPABASE_URL: string = import.meta.env.VITE_SUPABASE_URL;
export const SUPABASE_ANON_KEY: string = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  // Fails loudly at startup instead of every query silently 401-ing.
  // eslint-disable-next-line no-console
  console.error(
    "Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY. Check your .env file (see README-SUPABASE.md)."
  );
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export interface ApiErrorShape {
  message: string;
  status?: number;
  code?: string;
}

export function normalizeApiError(error: unknown): ApiErrorShape {
  if (error && typeof error === "object" && "message" in error) {
    const e = error as { message?: string; code?: string; status?: number };
    return {
      message: e.message || "Something went wrong while contacting Supabase.",
      code: e.code,
      status: e.status,
    };
  }
  if (error instanceof Error) return { message: error.message };
  return { message: "An unexpected error occurred." };
}

/** Throws a normalized error if a Supabase call returned one. */
export function assertNoError<T>(result: { data: T; error: unknown }): T {
  if (result.error) throw result.error;
  return result.data;
}
