import type {
  Alert,
  Customer,
  Order,
  OrderDetail,
  OrderStatus,
  OrderTimelineStep,
  Product,
  ProductionRecord,
  Recommendation,
  RiskLevel,
  Severity,
  StockStatus,
} from "@/types";

// ---------- products ----------

export interface ProductRow {
  id: string;
  code: string;
  name: string;
  category: string;
  warehouse: string;
  current_stock: number;
  reserved_stock: number;
  damaged_stock: number;
  safety_stock: number;
  reorder_level: number;
  lead_time_days: number;
  unit_cost?: number;
  updated_at: string;
}

export function computeAvailableStock(row: Pick<ProductRow, "current_stock" | "reserved_stock" | "damaged_stock">): number {
  return row.current_stock - row.reserved_stock - row.damaged_stock;
}

export function computeStockStatus(available: number, safetyStock: number, reorderLevel: number): StockStatus {
  if (available <= 0 || available < safetyStock) return "Critical";
  if (available < reorderLevel) return "Low";
  if (available > reorderLevel * 3) return "Overstock";
  return "Healthy";
}

export function mapProduct(row: ProductRow): Product {
  const availableStock = computeAvailableStock(row);
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    category: row.category,
    currentStock: row.current_stock,
    reservedStock: row.reserved_stock,
    damagedStock: row.damaged_stock,
    availableStock,
    safetyStock: row.safety_stock,
    reorderLevel: row.reorder_level,
    leadTimeDays: row.lead_time_days,
    warehouse: row.warehouse,
    stockStatus: computeStockStatus(availableStock, row.safety_stock, row.reorder_level),
    lastUpdated: row.updated_at,
  };
}

export function pickProduct(row: ProductRow): Pick<Product, "id" | "code" | "name"> {
  return { id: row.id, code: row.code, name: row.name };
}

// ---------- customers ----------

export interface CustomerRow {
  id: string;
  name: string;
  company?: string | null;
  email?: string | null;
  phone?: string | null;
}

export function mapCustomer(row: CustomerRow): Customer {
  return {
    id: row.id,
    name: row.name,
    company: row.company ?? undefined,
    email: row.email ?? undefined,
    phone: row.phone ?? undefined,
  };
}

// ---------- orders ----------

export interface OrderRow {
  id: string;
  quantity: number;
  order_date: string;
  required_date: string;
  priority: Order["priority"];
  status: OrderStatus;
  notes?: string | null;
  customer: CustomerRow;
  product: ProductRow;
}

/** Heuristic risk classification — mirrors what a real fulfillment engine would compute. */
export function computeOrderRisk(row: OrderRow): RiskLevel {
  const available = computeAvailableStock(row.product);
  const today = new Date();
  const required = new Date(row.required_date);
  const isTerminal = row.status === "Delivered" || row.status === "Cancelled";

  if (!isTerminal && available < row.quantity) return "Stock Shortage";
  if (!isTerminal && required < today) return "Delayed";
  if (!isTerminal && available - row.quantity < row.product.safety_stock) return "At Risk";
  return "Healthy";
}

export function mapOrder(row: OrderRow): Order {
  return {
    id: row.id,
    customer: mapCustomer(row.customer),
    product: pickProduct(row.product),
    quantity: row.quantity,
    orderDate: row.order_date,
    requiredDate: row.required_date,
    priority: row.priority,
    status: row.status,
    risk: computeOrderRisk(row),
    notes: row.notes ?? undefined,
  };
}

const ORDER_FLOW: OrderStatus[] = [
  "Pending",
  "Confirmed",
  "Processing",
  "Packed",
  "Ready to Ship",
  "Shipped",
  "In Transit",
  "Delivered",
];

export interface OrderStatusHistoryRow {
  id: string;
  label: string;
  status: string;
  timestamp: string;
}

export function buildTimeline(status: OrderStatus, history: OrderStatusHistoryRow[]): OrderTimelineStep[] {
  const byStatus = new Map(history.map((h) => [h.status, h]));
  if (status === "Cancelled") {
    return [{ label: "Cancelled", status: "completed", timestamp: byStatus.get("Cancelled")?.timestamp }];
  }
  const currentIndex = ORDER_FLOW.indexOf(status);
  return ORDER_FLOW.map((step, i) => ({
    label: step,
    status: i < currentIndex ? "completed" : i === currentIndex ? "active" : "pending",
    timestamp: byStatus.get(step)?.timestamp,
  }));
}

export function mapOrderDetail(row: OrderRow, history: OrderStatusHistoryRow[]): OrderDetail {
  const base = mapOrder(row);
  const available = computeAvailableStock(row.product);
  const shortage = Math.max(0, row.quantity - available);
  let severity: Severity | "NONE" = "NONE";
  if (shortage > 0) {
    severity = shortage >= row.quantity * 0.5 ? "Critical" : shortage >= row.quantity * 0.2 ? "High" : "Medium";
  }
  return {
    ...base,
    timeline: buildTimeline(row.status, history),
    inventoryAvailable: available,
    requiredQuantity: row.quantity,
    shortage,
    severity,
    recommendedAction: shortage > 0 ? "PRODUCE" : undefined,
  };
}

// ---------- production ----------

export interface ProductionRow {
  id: string;
  date: string;
  planned: number;
  produced: number;
  rejected: number;
  status: ProductionRecord["status"];
  product: ProductRow;
}

export function mapProduction(row: ProductionRow): ProductionRecord {
  return {
    id: row.id,
    product: pickProduct(row.product),
    date: row.date,
    planned: row.planned,
    produced: row.produced,
    rejected: row.rejected,
    efficiency: row.planned > 0 ? Math.round((row.produced / row.planned) * 1000) / 10 : 0,
    status: row.status,
  };
}

// ---------- alerts ----------

export interface AlertRow {
  id: string;
  severity: Severity;
  type: Alert["type"];
  title: string;
  detected_at: string;
  status: Alert["status"];
  description?: string | null;
  product?: ProductRow | null;
  order?: { id: string } | null;
}

export function mapAlert(row: AlertRow): Alert {
  return {
    id: row.id,
    severity: row.severity,
    type: row.type,
    title: row.title,
    product: row.product ? pickProduct(row.product) : undefined,
    order: row.order ? { id: row.order.id } : undefined,
    detectedAt: row.detected_at,
    status: row.status,
    description: row.description ?? undefined,
  };
}

// ---------- recommendations ----------

export interface RecommendationRow {
  id: string;
  current_stock: number;
  predicted_demand: number;
  safety_stock: number;
  reorder_point: number;
  recommended_quantity: number;
  action: Recommendation["action"];
  priority: Severity;
  status: Recommendation["status"];
  reason?: string | null;
  product: ProductRow;
}

export function mapRecommendation(row: RecommendationRow): Recommendation {
  return {
    id: row.id,
    product: pickProduct(row.product),
    currentStock: row.current_stock,
    predictedDemand: row.predicted_demand,
    safetyStock: row.safety_stock,
    reorderPoint: row.reorder_point,
    recommendedQuantity: row.recommended_quantity,
    action: row.action,
    priority: row.priority,
    status: row.status,
    reason: row.reason ?? "",
  };
}
