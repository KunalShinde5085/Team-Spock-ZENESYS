import type { LucideIcon } from "lucide-react";
import { clsx } from "clsx";
import { TrendingDown, TrendingUp } from "lucide-react";

interface KpiCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  tone?: "neutral" | "critical" | "warning" | "success";
  delta?: { value: string; positive: boolean };
  subtext?: string;
}

const toneRing: Record<string, string> = {
  neutral: "text-brand bg-brand/10",
  critical: "text-critical bg-critical-bg",
  warning: "text-warning bg-warning-bg",
  success: "text-success bg-success-bg",
};

export function KpiCard({ label, value, icon: Icon, tone = "neutral", delta, subtext }: KpiCardProps) {
  return (
    <div className="panel p-4 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="label-eyebrow">{label}</span>
        <span className={clsx("flex h-7 w-7 items-center justify-center rounded", toneRing[tone])}>
          <Icon size={15} strokeWidth={2} />
        </span>
      </div>
      <div className="flex items-end justify-between">
        <span className="kpi-value">{value}</span>
        {delta && (
          <span
            className={clsx(
              "flex items-center gap-0.5 text-2xs font-medium",
              delta.positive ? "text-success" : "text-critical"
            )}
          >
            {delta.positive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {delta.value}
          </span>
        )}
      </div>
      {subtext && <span className="text-2xs text-text-secondary">{subtext}</span>}
    </div>
  );
}
