import { AlertTriangle, RotateCw } from "lucide-react";

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-critical-bg text-critical">
        <AlertTriangle size={20} />
      </div>
      <p className="text-sm font-medium text-text-primary">Couldn't load this data</p>
      <p className="max-w-sm text-2xs text-text-secondary">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="btn-secondary mt-1">
          <RotateCw size={13} />
          Retry
        </button>
      )}
    </div>
  );
}
