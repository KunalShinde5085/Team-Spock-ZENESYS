import { clsx } from "clsx";
import type { ReactNode } from "react";

type Tone = "neutral" | "success" | "warning" | "critical" | "accent" | "brand";

const toneClasses: Record<Tone, string> = {
  neutral: "bg-gray-100 text-gray-700 border-gray-200",
  success: "bg-success-bg text-success border-success/20",
  warning: "bg-warning-bg text-warning border-warning/20",
  critical: "bg-critical-bg text-critical border-critical/20",
  accent: "bg-blue-50 text-accent border-blue-200",
  brand: "bg-brand/10 text-brand border-brand/20",
};

export function Badge({ tone = "neutral", children }: { tone?: Tone; children: ReactNode }) {
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1 rounded-sm border px-2 py-0.5 text-2xs font-medium whitespace-nowrap",
        toneClasses[tone]
      )}
    >
      {children}
    </span>
  );
}

export function statusTone(status: string): Tone {
  const s = status.toLowerCase();
  if (["delivered", "healthy", "completed", "approved", "resolved"].includes(s)) return "success";
  if (["cancelled", "critical", "delayed", "rejected", "dismissed", "stock shortage"].includes(s))
    return "critical";
  if (["low", "at risk", "pending", "open", "overstock"].includes(s)) return "warning";
  if (["processing", "confirmed", "in transit", "acknowledged", "shipped"].includes(s))
    return "accent";
  return "neutral";
}
