import { Bell, Menu, Search } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const titleMap: Record<string, string> = {
  "/": "Overview",
  "/orders": "Orders",
  "/inventory": "Inventory",
  "/production": "Production",
  "/forecast": "Demand Forecast",
  "/recommendations": "Recommendations",
  "/alerts": "Alerts",
  "/analytics": "Analytics",
  "/settings": "Settings",
};

function useBreadcrumb(pathname: string) {
  const segments = pathname.split("/").filter(Boolean);
  if (segments.length === 0) return [{ label: "Overview", to: "/" }];
  const crumbs = [{ label: "Overview", to: "/" }];
  let acc = "";
  segments.forEach((seg) => {
    acc += `/${seg}`;
    const label = titleMap[acc] || seg.replace(/-/g, " ");
    crumbs.push({ label: label.charAt(0).toUpperCase() + label.slice(1), to: acc });
  });
  return crumbs;
}

export function Header({ onMenuClick }: { onMenuClick: () => void }) {
  const { pathname } = useLocation();
  const crumbs = useBreadcrumb(pathname);

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-surface px-4 py-3 lg:px-6">
      <div className="flex items-center gap-3">
        <button className="text-text-secondary lg:hidden" onClick={onMenuClick}>
          <Menu size={20} />
        </button>
        <nav className="flex items-center gap-1.5 text-sm">
          {crumbs.map((c, i) => (
            <span key={c.to} className="flex items-center gap-1.5">
              {i > 0 && <span className="text-text-secondary">/</span>}
              {i === crumbs.length - 1 ? (
                <span className="font-medium text-text-primary">{c.label}</span>
              ) : (
                <Link to={c.to} className="text-text-secondary hover:text-text-primary">
                  {c.label}
                </Link>
              )}
            </span>
          ))}
        </nav>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative hidden sm:block">
          <Search
            size={14}
            className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-text-secondary"
          />
          <input
            type="text"
            placeholder="Search orders, products, SKUs…"
            className="w-64 rounded-md border border-border bg-bg py-1.5 pl-8 pr-3 text-sm text-text-primary placeholder:text-text-secondary focus:border-accent focus:ring-1 focus:ring-accent outline-none"
          />
        </div>
        <button className="relative flex h-8 w-8 items-center justify-center rounded-md text-text-secondary hover:bg-bg">
          <Bell size={17} />
          <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-critical" />
        </button>
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand/10 text-xs font-semibold text-brand">
          AV
        </span>
      </div>
    </header>
  );
}
