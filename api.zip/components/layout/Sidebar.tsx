import { NavLink } from "react-router-dom";
import { clsx } from "clsx";
import {
  LayoutDashboard,
  ClipboardList,
  Boxes,
  Factory,
  LineChart,
  Lightbulb,
  BellRing,
  BarChart3,
  Settings,
  LogOut,
  Hexagon,
} from "lucide-react";

const navItems = [
  { to: "/", label: "Overview", icon: LayoutDashboard, end: true },
  { to: "/orders", label: "Orders", icon: ClipboardList },
  { to: "/inventory", label: "Inventory", icon: Boxes },
  { to: "/production", label: "Production", icon: Factory },
  { to: "/forecast", label: "Demand Forecast", icon: LineChart },
  { to: "/recommendations", label: "Recommendations", icon: Lightbulb },
  { to: "/alerts", label: "Alerts", icon: BellRing },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar({ mobileOpen, onCloseMobile }: { mobileOpen: boolean; onCloseMobile: () => void }) {
  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-gray-900/50 lg:hidden"
          onClick={onCloseMobile}
        />
      )}
      <aside
        className={clsx(
          "fixed inset-y-0 left-0 z-50 flex w-60 flex-col bg-sidebar transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex items-center gap-2.5 px-5 py-5 border-b border-white/10">
          <span className="flex h-8 w-8 items-center justify-center rounded bg-brand text-white">
            <Hexagon size={17} strokeWidth={2.5} />
          </span>
          <div className="leading-tight">
            <p className="text-sm font-semibold text-white tracking-wide">MECHFLOW</p>
            <p className="text-2xs text-gray-400">Intelligent Manufacturing Platform</p>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <ul className="flex flex-col gap-0.5">
            {navItems.map(({ to, label, icon: Icon, end }) => (
              <li key={to}>
                <NavLink
                  to={to}
                  end={end}
                  onClick={onCloseMobile}
                  className={({ isActive }) =>
                    clsx(
                      "flex items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors",
                      isActive
                        ? "bg-sidebar-hover text-white font-medium"
                        : "text-gray-400 hover:bg-sidebar-hover hover:text-gray-100"
                    )
                  }
                >
                  <Icon size={16} strokeWidth={2} />
                  {label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className="border-t border-white/10 px-3 py-4">
          <div className="flex items-center gap-2.5 rounded-md px-2 py-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand/30 text-xs font-semibold text-white">
              AV
            </span>
            <div className="leading-tight">
              <p className="text-sm font-medium text-white">Aditya Verma</p>
              <p className="text-2xs text-gray-400">Operations Manager</p>
            </div>
          </div>
          <button className="mt-1 flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-sm text-gray-400 hover:bg-sidebar-hover hover:text-gray-100">
            <LogOut size={16} />
            Logout
          </button>
        </div>
      </aside>
    </>
  );
}
