import { useState } from "react";
import {
  Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { PageHeader } from "@/components/common/PageHeader";
import { Skeleton } from "@/components/common/Skeleton";
import { EmptyState } from "@/components/common/EmptyState";
import { useQuery } from "@tanstack/react-query";
import { analyticsApi } from "@/api/analytics";

function useAnalytics(dateFrom?: string, dateTo?: string) {
  return useQuery({
    queryKey: ["analytics", dateFrom, dateTo],
    queryFn: () => analyticsApi.get(dateFrom, dateTo),
  });
}

export default function Analytics() {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const { data, isLoading, isError } = useAnalytics(dateFrom || undefined, dateTo || undefined);

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="Analytics"
        subtitle="Executive-level trends across demand, fulfillment, and production."
        actions={
          <div className="flex items-center gap-2">
            <input type="date" className="input-field w-auto" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            <span className="text-text-secondary text-sm">to</span>
            <input type="date" className="input-field w-auto" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
          </div>
        }
      />

      {isLoading && (
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-64 w-full" />)}
        </div>
      )}

      {isError && (
        <div className="panel p-4">
          <EmptyState title="Analytics data unavailable" description="Once the analytics API is connected, executive charts will render here." />
        </div>
      )}

      {data && (
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          <ChartPanel title="Monthly Demand Trend">
            <LineChart data={data.monthlyDemandTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
              <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={{ stroke: "#E5E7EB" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
              <Line type="monotone" dataKey="demand" stroke="#0F4C5C" strokeWidth={2} dot={false} />
            </LineChart>
          </ChartPanel>

          <ChartPanel title="Top 10 Products by Demand">
            <BarChart data={data.topProducts} layout="vertical" margin={{ left: 24 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} width={90} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
              <Bar dataKey="demand" fill="#2563EB" radius={[0, 3, 3, 0]} />
            </BarChart>
          </ChartPanel>

          <ChartPanel title="Order Fulfillment Performance">
            <BarChart data={data.fulfillmentPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
              <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={{ stroke: "#E5E7EB" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
              <Bar dataKey="onTime" stackId="a" fill="#16A34A" radius={[0, 0, 0, 0]} />
              <Bar dataKey="delayed" stackId="a" fill="#DC2626" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ChartPanel>

          <ChartPanel title="Inventory Health Distribution">
            <BarChart data={data.inventoryHealth}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
              <XAxis dataKey="status" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={{ stroke: "#E5E7EB" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
              <Bar dataKey="count" radius={[3, 3, 0, 0]}>
                {data.inventoryHealth.map((entry, i) => (
                  <Cell key={i} fill={{ Critical: "#DC2626", Low: "#D97706", Healthy: "#16A34A", Overstock: "#2563EB" }[entry.status] || "#6B7280"} />
                ))}
              </Bar>
            </BarChart>
          </ChartPanel>

          <ChartPanel title="Production Efficiency">
            <LineChart data={data.productionEfficiency}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
              <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={{ stroke: "#E5E7EB" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
              <Line type="monotone" dataKey="efficiency" stroke="#16A34A" strokeWidth={2} dot={false} />
            </LineChart>
          </ChartPanel>

          <ChartPanel title="Rejection Rate by Product">
            <BarChart data={data.rejectionByProduct}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={{ stroke: "#E5E7EB" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
              <Bar dataKey="rate" fill="#D97706" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ChartPanel>

          <ChartPanel title="Forecast Accuracy">
            <LineChart data={data.forecastAccuracy}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
              <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={{ stroke: "#E5E7EB" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
              <Line type="monotone" dataKey="accuracy" stroke="#2563EB" strokeWidth={2} dot={false} />
            </LineChart>
          </ChartPanel>

          <ChartPanel title="Delayed Orders Trend">
            <BarChart data={data.delayedOrdersTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
              <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={{ stroke: "#E5E7EB" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
              <Bar dataKey="count" fill="#DC2626" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ChartPanel>
        </div>
      )}
    </div>
  );
}

function ChartPanel({ title, children }: { title: string; children: React.ReactElement }) {
  return (
    <div className="panel">
      <div className="panel-header"><h2 className="text-sm font-semibold">{title}</h2></div>
      <div className="p-4">
        <ResponsiveContainer width="100%" height={240}>{children}</ResponsiveContainer>
      </div>
    </div>
  );
}
