import { useState } from "react";
import { PageHeader } from "@/components/common/PageHeader";
import { Badge, statusTone } from "@/components/common/Badge";
import { TableSkeleton } from "@/components/common/Skeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { EmptyState } from "@/components/common/EmptyState";
import { useAlerts, useUpdateAlert } from "@/hooks/useAlerts";
import type { Severity } from "@/types";
import { formatRelativeTime } from "@/utils/format";
import { clsx } from "clsx";

const TABS: { label: string; severity?: Severity; status?: "Resolved" }[] = [
  { label: "All" },
  { label: "Critical", severity: "Critical" },
  { label: "High", severity: "High" },
  { label: "Medium", severity: "Medium" },
  { label: "Resolved", status: "Resolved" },
];

export default function Alerts() {
  const [tab, setTab] = useState(0);
  const active = TABS[tab];
  const { data, isLoading, isError, refetch } = useAlerts({ severity: active.severity, status: active.status });
  const updateAlert = useUpdateAlert();

  return (
    <div className="flex flex-col gap-5">
      <PageHeader title="Operational Alerts" subtitle="Live issues detected across orders, inventory, and production." />

      <div className="flex gap-1 border-b border-border">
        {TABS.map((t, i) => (
          <button
            key={t.label}
            onClick={() => setTab(i)}
            className={clsx(
              "px-3.5 py-2 text-sm font-medium border-b-2 -mb-px transition-colors",
              tab === i ? "border-brand text-brand" : "border-transparent text-text-secondary hover:text-text-primary"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="panel overflow-hidden">
        {isLoading && <TableSkeleton rows={8} cols={8} />}
        {isError && <div className="p-4"><ErrorState message="Could not load alerts." onRetry={() => refetch()} /></div>}
        {data && data.length === 0 && <EmptyState title="No alerts in this view" description="All monitored systems are within normal thresholds." />}
        {data && data.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-th">Severity</th>
                  <th className="table-th">Type</th>
                  <th className="table-th">Title</th>
                  <th className="table-th">Product</th>
                  <th className="table-th">Order</th>
                  <th className="table-th">Detected</th>
                  <th className="table-th">Status</th>
                  <th className="table-th">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.map((a) => (
                  <tr key={a.id} className={clsx("hover:bg-bg/60", a.severity === "Critical" && "bg-critical-bg/40")}>
                    <td className="table-td"><Badge tone={statusTone(a.severity)}>{a.severity}</Badge></td>
                    <td className="table-td text-text-secondary">{a.type}</td>
                    <td className="table-td font-medium">{a.title}</td>
                    <td className="table-td text-text-secondary">{a.product?.name ?? "—"}</td>
                    <td className="table-td text-text-secondary">{a.order?.id ?? "—"}</td>
                    <td className="table-td text-text-secondary">{formatRelativeTime(a.detectedAt)}</td>
                    <td className="table-td"><Badge tone={statusTone(a.status)}>{a.status}</Badge></td>
                    <td className="table-td">
                      <div className="flex gap-2">
                        {a.status === "Open" && (
                          <button className="text-accent font-medium hover:underline" onClick={() => updateAlert.mutate({ id: a.id, status: "Acknowledged" })}>Acknowledge</button>
                        )}
                        {a.status !== "Resolved" && (
                          <button className="text-success font-medium hover:underline" onClick={() => updateAlert.mutate({ id: a.id, status: "Resolved" })}>Resolve</button>
                        )}
                        {a.status !== "Dismissed" && a.status !== "Resolved" && (
                          <button className="text-text-secondary font-medium hover:underline" onClick={() => updateAlert.mutate({ id: a.id, status: "Dismissed" })}>Dismiss</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
