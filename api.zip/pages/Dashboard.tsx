import {
  ClipboardList,
  AlertTriangle,
  IndianRupee,
  PackageSearch,
  TrendingUp,
  Siren,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PageHeader } from "@/components/common/PageHeader";
import { KpiCard } from "@/components/common/KpiCard";
import { KpiSkeleton, Skeleton } from "@/components/common/Skeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { EmptyState } from "@/components/common/EmptyState";
import { Badge, statusTone } from "@/components/common/Badge";
import {
  useDashboardKpis,
  useDemandVsInventory,
  useFulfillmentBreakdown,
  useInventoryRiskBreakdown,
} from "@/hooks/useDashboard";
import { useAlerts } from "@/hooks/useAlerts";
import { formatCurrency, formatNumber, formatRelativeTime } from "@/utils/format";

const RISK_COLORS: Record<string, string> = {
  Critical: "#DC2626",
  Low: "#D97706",
  Healthy: "#16A34A",
  Overstock: "#2563EB",
};

const FULFILLMENT_COLORS = ["#0F4C5C", "#15616F", "#2563EB", "#6B7280", "#16A34A", "#D97706"];

export default function Dashboard() {
  const kpis = useDashboardKpis();
  const fulfillment = useFulfillmentBreakdown();
  const invRisk = useInventoryRiskBreakdown();
  const demandChart = useDemandVsInventory();
  const alerts = useAlerts({ status: "Open" });

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="Executive Overview"
        subtitle="Real-time snapshot of orders, inventory, and demand across the factory."
      />

      {/* KPI Row */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        {kpis.isLoading &&
          Array.from({ length: 6 }).map((_, i) => <KpiSkeleton key={i} />)}

        {kpis.isError && (
          <div className="col-span-full">
            <ErrorState
              message="Could not load KPI summary from the server."
              onRetry={() => kpis.refetch()}
            />
          </div>
        )}

        {kpis.data && (
          <>
            <KpiCard
              label="Active Orders"
              value={formatNumber(kpis.data.activeOrders)}
              icon={ClipboardList}
              delta={{
                value: `${kpis.data.activeOrdersDelta > 0 ? "+" : ""}${kpis.data.activeOrdersDelta}%`,
                positive: kpis.data.activeOrdersDelta >= 0,
              }}
              subtext="from last week"
            />
            <KpiCard
              label="Orders At Risk"
              value={formatNumber(kpis.data.ordersAtRisk)}
              icon={AlertTriangle}
              tone="critical"
              subtext="need attention"
            />
            <KpiCard
              label="Inventory Value"
              value={formatCurrency(kpis.data.inventoryValue)}
              icon={IndianRupee}
              tone="neutral"
              subtext="current valuation"
            />
            <KpiCard
              label="Low Stock Items"
              value={formatNumber(kpis.data.lowStockItems)}
              icon={PackageSearch}
              tone="warning"
              subtext="below reorder level"
            />
            <KpiCard
              label="Forecasted Demand"
              value={`${formatNumber(kpis.data.forecastedDemand30d)} u`}
              icon={TrendingUp}
              tone="neutral"
              subtext="next 30 days"
            />
            <KpiCard
              label="Critical Alerts"
              value={formatNumber(kpis.data.openCriticalAlerts)}
              icon={Siren}
              tone="critical"
              subtext="open, unresolved"
            />
          </>
        )}
      </div>

      {/* Fulfillment + Risk */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <div className="panel">
          <div className="panel-header">
            <h2 className="text-sm font-semibold">Order Fulfillment Status</h2>
          </div>
          <div className="p-4">
            {fulfillment.isLoading && <Skeleton className="h-52 w-full" />}
            {fulfillment.isError && (
              <ErrorState message="Fulfillment breakdown unavailable." onRetry={() => fulfillment.refetch()} />
            )}
            {fulfillment.data && fulfillment.data.length === 0 && (
              <EmptyState title="No order data yet" description="Fulfillment status will appear once orders are placed." />
            )}
            {fulfillment.data && fulfillment.data.length > 0 && (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={fulfillment.data}
                    dataKey="count"
                    nameKey="status"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={2}
                  >
                    {fulfillment.data.map((entry, i) => (
                      <Cell key={entry.status} fill={FULFILLMENT_COLORS[i % FULFILLMENT_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend layout="vertical" verticalAlign="middle" align="right" wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <h2 className="text-sm font-semibold">Inventory Risk Overview</h2>
          </div>
          <div className="p-4">
            {invRisk.isLoading && <Skeleton className="h-52 w-full" />}
            {invRisk.isError && (
              <ErrorState message="Inventory risk data unavailable." onRetry={() => invRisk.refetch()} />
            )}
            {invRisk.data && invRisk.data.length === 0 && (
              <EmptyState title="No inventory data yet" />
            )}
            {invRisk.data && invRisk.data.length > 0 && (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={invRisk.data}
                    dataKey="count"
                    nameKey="status"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={2}
                  >
                    {invRisk.data.map((entry) => (
                      <Cell key={entry.status} fill={RISK_COLORS[entry.status] || "#6B7280"} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend layout="vertical" verticalAlign="middle" align="right" wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Demand vs Inventory */}
      <div className="panel">
        <div className="panel-header">
          <h2 className="text-sm font-semibold">Demand vs. Inventory</h2>
          <div className="flex items-center gap-3 text-2xs text-text-secondary">
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-brand" />Historical</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-accent" />Forecasted</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-gray-400" />Inventory</span>
          </div>
        </div>
        <div className="p-4">
          {demandChart.isLoading && <Skeleton className="h-64 w-full" />}
          {demandChart.isError && (
            <ErrorState message="Demand chart data unavailable." onRetry={() => demandChart.refetch()} />
          )}
          {demandChart.data && demandChart.data.length === 0 && (
            <EmptyState title="No demand history yet" description="Once orders and forecasts accumulate, trends will appear here." />
          )}
          {demandChart.data && demandChart.data.length > 0 && (
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={demandChart.data}>
                <defs>
                  <linearGradient id="histGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0F4C5C" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="#0F4C5C" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="forecastGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#2563EB" stopOpacity={0.2} />
                    <stop offset="100%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
                <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#6B7280" }} axisLine={{ stroke: "#E5E7EB" }} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid #E5E7EB" }} />
                <Area type="monotone" dataKey="historical" stroke="#0F4C5C" fill="url(#histGrad)" strokeWidth={2} name="Historical" />
                <Area type="monotone" dataKey="forecast" stroke="#2563EB" strokeDasharray="5 4" fill="url(#forecastGrad)" strokeWidth={2} name="Forecasted" />
                <Area type="monotone" dataKey="inventory" stroke="#6B7280" fill="none" strokeWidth={1.5} name="Inventory" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Alerts table */}
      <div className="panel">
        <div className="panel-header">
          <h2 className="text-sm font-semibold">Operational Alerts</h2>
        </div>
        {alerts.isLoading && <Skeleton className="h-40 w-full m-4" />}
        {alerts.isError && (
          <div className="p-4">
            <ErrorState message="Could not load alerts." onRetry={() => alerts.refetch()} />
          </div>
        )}
        {alerts.data && alerts.data.length === 0 && (
          <EmptyState title="No open alerts" description="Everything is operating within normal thresholds." />
        )}
        {alerts.data && alerts.data.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-th">Severity</th>
                  <th className="table-th">Issue</th>
                  <th className="table-th">Product</th>
                  <th className="table-th">Affected Order</th>
                  <th className="table-th">Detected</th>
                  <th className="table-th">Status</th>
                  <th className="table-th">Action</th>
                </tr>
              </thead>
              <tbody>
                {alerts.data.map((a) => (
                  <tr key={a.id} className="hover:bg-bg/60">
                    <td className="table-td">
                      <Badge tone={statusTone(a.severity)}>{a.severity}</Badge>
                    </td>
                    <td className="table-td font-medium">{a.title}</td>
                    <td className="table-td text-text-secondary">{a.product?.name ?? "—"}</td>
                    <td className="table-td text-text-secondary">{a.order?.id ?? "—"}</td>
                    <td className="table-td text-text-secondary">{formatRelativeTime(a.detectedAt)}</td>
                    <td className="table-td">
                      <Badge tone={statusTone(a.status)}>{a.status}</Badge>
                    </td>
                    <td className="table-td">
                      <button className="text-accent font-medium hover:underline">View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
