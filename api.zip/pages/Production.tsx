import { useState } from "react";
import { PageHeader } from "@/components/common/PageHeader";
import { KpiCard } from "@/components/common/KpiCard";
import { Badge, statusTone } from "@/components/common/Badge";
import { TableSkeleton, KpiSkeleton } from "@/components/common/Skeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { EmptyState } from "@/components/common/EmptyState";
import { useProduction } from "@/hooks/useProduction";
import { Factory, Gauge, CheckSquare, XSquare } from "lucide-react";
import { formatDate, formatNumber } from "@/utils/format";

export default function Production() {
  const [search, setSearch] = useState("");
  const { data, isLoading, isError, refetch } = useProduction({ search: search || undefined });

  const totals = data?.reduce(
    (acc, r) => ({
      planned: acc.planned + r.planned,
      produced: acc.produced + r.produced,
      rejected: acc.rejected + r.rejected,
    }),
    { planned: 0, produced: 0, rejected: 0 }
  );
  const efficiency = totals && totals.planned > 0 ? (totals.produced / totals.planned) * 100 : 0;
  const rejectionRate = totals && totals.produced > 0 ? (totals.rejected / totals.produced) * 100 : 0;

  return (
    <div className="flex flex-col gap-5">
      <PageHeader title="Production Management" subtitle="Track planned vs. actual output across production runs." />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {isLoading ? (
          Array.from({ length: 4 }).map((_, i) => <KpiSkeleton key={i} />)
        ) : (
          <>
            <KpiCard label="Planned Production" value={formatNumber(totals?.planned ?? 0)} icon={Factory} />
            <KpiCard label="Actual Production" value={formatNumber(totals?.produced ?? 0)} icon={CheckSquare} tone="success" />
            <KpiCard label="Production Efficiency" value={`${efficiency.toFixed(1)}%`} icon={Gauge} tone={efficiency < 85 ? "warning" : "success"} />
            <KpiCard label="Rejection Rate" value={`${rejectionRate.toFixed(1)}%`} icon={XSquare} tone={rejectionRate > 5 ? "critical" : "neutral"} />
          </>
        )}
      </div>

      <div className="panel p-3">
        <input className="input-field max-w-xs" placeholder="Search product or production ID…" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      <div className="panel overflow-hidden">
        {isLoading && <TableSkeleton rows={8} cols={8} />}
        {isError && <div className="p-4"><ErrorState message="Could not load production records." onRetry={() => refetch()} /></div>}
        {data && data.length === 0 && <EmptyState title="No production records" description="Scheduled and completed production runs will appear here." />}
        {data && data.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-th">ID</th>
                  <th className="table-th">Product</th>
                  <th className="table-th">Date</th>
                  <th className="table-th">Planned</th>
                  <th className="table-th">Produced</th>
                  <th className="table-th">Rejected</th>
                  <th className="table-th">Efficiency</th>
                  <th className="table-th">Status</th>
                </tr>
              </thead>
              <tbody>
                {data.map((r) => (
                  <tr key={r.id} className="hover:bg-bg/60">
                    <td className="table-td font-medium">{r.id}</td>
                    <td className="table-td">{r.product.name}</td>
                    <td className="table-td text-text-secondary">{formatDate(r.date)}</td>
                    <td className="table-td tabular-nums">{r.planned}</td>
                    <td className="table-td tabular-nums">{r.produced}</td>
                    <td className="table-td tabular-nums text-critical">{r.rejected}</td>
                    <td className="table-td tabular-nums">{r.efficiency.toFixed(1)}%</td>
                    <td className="table-td"><Badge tone={statusTone(r.status)}>{r.status}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
