import { useState } from "react";
import { Link } from "react-router-dom";
import { Plus, Search } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Badge, statusTone } from "@/components/common/Badge";
import { TableSkeleton } from "@/components/common/Skeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { EmptyState } from "@/components/common/EmptyState";
import { useOrders } from "@/hooks/useOrders";
import type { OrderFilters, OrderPriority, OrderStatus } from "@/types";
import { formatDate } from "@/utils/format";

const STATUS_OPTIONS: OrderStatus[] = [
  "Pending", "Confirmed", "Processing", "Packed", "Ready to Ship",
  "Shipped", "In Transit", "Delivered", "Cancelled",
];
const PRIORITY_OPTIONS: OrderPriority[] = ["Low", "Medium", "High", "Urgent"];

export default function Orders() {
  const [filters, setFilters] = useState<OrderFilters>({ page: 1, pageSize: 20 });
  const { data, isLoading, isError, refetch } = useOrders(filters);

  const update = (patch: Partial<OrderFilters>) => setFilters((f) => ({ ...f, ...patch, page: 1 }));

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="Orders"
        subtitle="Track and manage customer orders across the fulfillment lifecycle."
        actions={
          <Link to="/orders/new" className="btn-primary">
            <Plus size={15} />
            Create Order
          </Link>
        }
      />

      <div className="panel p-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-text-secondary" />
            <input
              className="input-field pl-8"
              placeholder="Search order ID, customer, product…"
              onChange={(e) => update({ search: e.target.value || undefined })}
            />
          </div>
          <select
            className="input-field w-auto"
            onChange={(e) => update({ status: (e.target.value || undefined) as OrderStatus | undefined })}
          >
            <option value="">All statuses</option>
            {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <select
            className="input-field w-auto"
            onChange={(e) => update({ priority: (e.target.value || undefined) as OrderPriority | undefined })}
          >
            <option value="">All priorities</option>
            {PRIORITY_OPTIONS.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
          <input type="date" className="input-field w-auto" onChange={(e) => update({ dateFrom: e.target.value || undefined })} />
        </div>
      </div>

      <div className="panel overflow-hidden">
        {isLoading && <TableSkeleton rows={8} cols={9} />}
        {isError && (
          <div className="p-4">
            <ErrorState message="Could not load orders from the server." onRetry={() => refetch()} />
          </div>
        )}
        {data && data.data.length === 0 && (
          <EmptyState
            title="No orders match these filters"
            description="Try adjusting your filters, or create a new order to get started."
          />
        )}
        {data && data.data.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-th">Order ID</th>
                  <th className="table-th">Customer</th>
                  <th className="table-th">Product</th>
                  <th className="table-th">Qty</th>
                  <th className="table-th">Order Date</th>
                  <th className="table-th">Required Date</th>
                  <th className="table-th">Priority</th>
                  <th className="table-th">Status</th>
                  <th className="table-th">Risk</th>
                </tr>
              </thead>
              <tbody>
                {data.data.map((o) => (
                  <tr key={o.id} className="hover:bg-bg/60 cursor-pointer">
                    <td className="table-td">
                      <Link to={`/orders/${o.id}`} className="font-medium text-accent hover:underline">
                        {o.id}
                      </Link>
                    </td>
                    <td className="table-td">{o.customer.name}</td>
                    <td className="table-td text-text-secondary">{o.product.name}</td>
                    <td className="table-td tabular-nums">{o.quantity}</td>
                    <td className="table-td text-text-secondary">{formatDate(o.orderDate)}</td>
                    <td className="table-td text-text-secondary">{formatDate(o.requiredDate)}</td>
                    <td className="table-td"><Badge tone={o.priority === "Urgent" || o.priority === "High" ? "critical" : "neutral"}>{o.priority}</Badge></td>
                    <td className="table-td"><Badge tone={statusTone(o.status)}>{o.status}</Badge></td>
                    <td className="table-td"><Badge tone={statusTone(o.risk)}>{o.risk}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
