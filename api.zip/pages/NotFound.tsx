import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-24 text-center">
      <p className="text-3xl font-semibold text-text-primary">404</p>
      <p className="text-sm text-text-secondary">This page doesn't exist.</p>
      <Link to="/" className="btn-primary mt-2">Back to Overview</Link>
    </div>
  );
}
