import { PageHeader } from "@/components/common/PageHeader";
import { Badge, statusTone } from "@/components/common/Badge";
import { TableSkeleton } from "@/components/common/Skeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { EmptyState } from "@/components/common/EmptyState";
import { useRecommendations, useUpdateRecommendation } from "@/hooks/useRecommendations";
import { formatNumber } from "@/utils/format";

export default function Recommendations() {
  const { data, isLoading, isError, refetch } = useRecommendations();
  const updateRec = useUpdateRecommendation();

  return (
    <div className="flex flex-col gap-5">
      <PageHeader title="Inventory & Purchasing Recommendations" subtitle="Analytics-driven actions to prevent stockouts and overstock." />

      {isLoading && <div className="panel"><TableSkeleton rows={5} cols={7} /></div>}
      {isError && <div className="panel p-4"><ErrorState message="Could not load recommendations." onRetry={() => refetch()} /></div>}
      {data && data.length === 0 && (
        <div className="panel"><EmptyState title="No recommendations right now" description="MachinIQ will surface produce/purchase actions here as demand signals change." /></div>
      )}

      {data && data.length > 0 && (
        <div className="flex flex-col gap-3">
          {data.map((r) => (
            <div key={r.id} className="panel p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-semibold">{r.product.name}</h3>
                    <span className="text-2xs text-text-secondary font-mono">{r.product.code}</span>
                    <Badge tone={statusTone(r.priority)}>{r.priority}</Badge>
                    <Badge tone={statusTone(r.status)}>{r.status}</Badge>
                  </div>
                  <p className="mt-1.5 text-sm text-text-secondary max-w-xl">{r.reason}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    className="btn-secondary"
                    disabled={r.status !== "Pending"}
                    onClick={() => updateRec.mutate({ id: r.id, status: "Rejected" })}
                  >
                    Reject
                  </button>
                  <button
                    className="btn-primary"
                    disabled={r.status !== "Pending"}
                    onClick={() => updateRec.mutate({ id: r.id, status: "Approved" })}
                  >
                    Approve
                  </button>
                  {r.status === "Approved" && (
                    <button className="btn-secondary" onClick={() => updateRec.mutate({ id: r.id, status: "Completed" })}>
                      Mark Completed
                    </button>
                  )}
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-4 border-t border-border pt-4 text-sm sm:grid-cols-3 xl:grid-cols-6">
                <Stat label="Current Stock" value={formatNumber(r.currentStock)} />
                <Stat label="Predicted Demand" value={formatNumber(r.predictedDemand)} />
                <Stat label="Safety Stock" value={formatNumber(r.safetyStock)} />
                <Stat label="Reorder Point" value={formatNumber(r.reorderPoint)} />
                <Stat label="Recommended Qty" value={formatNumber(r.recommendedQuantity)} highlight />
                <Stat label="Action" value={r.action} highlight />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div>
      <p className="label-eyebrow mb-1">{label}</p>
      <p className={`font-semibold tabular-nums ${highlight ? "text-brand" : "text-text-primary"}`}>{value}</p>
    </div>
  );
}
