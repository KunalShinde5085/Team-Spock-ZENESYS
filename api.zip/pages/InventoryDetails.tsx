import { useParams } from "react-router-dom";
import { Line, LineChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { PageHeader } from "@/components/common/PageHeader";
import { Badge, statusTone } from "@/components/common/Badge";
import { Skeleton } from "@/components/common/Skeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { EmptyState } from "@/components/common/EmptyState";
import { useInventoryDetail } from "@/hooks/useInventory";
import { formatDate, formatRelativeTime } from "@/utils/format";

export default function InventoryDetails() {
  const { id = "" } = useParams();
  const { data, isLoading, isError, refetch } = useInventoryDetail(id);

  if (isLoading) return <Skeleton className="h-96 w-full" />;
  if (isError || !data) return <ErrorState message="Could not load this inventory item." onRetry={() => refetch()} />;

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title={`${data.code} — ${data.name}`}
        subtitle={`${data.category} · ${data.warehouse}`}
        actions={<Badge tone={statusTone(data.stockStatus)}>{data.stockStatus}</Badge>}
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        {[
          ["Current Stock", data.currentStock],
          ["Reserved", data.reservedStock],
          ["Available", data.availableStock],
          ["Damaged", data.damagedStock],
          ["Safety Stock", data.safetyStock],
          ["Reorder Level", data.reorderLevel],
        ].map(([label, value]) => (
          <div key={label as string} className="panel p-4">
            <p className="label-eyebrow mb-1.5">{label}</p>
            <p className="kpi-value">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="panel xl:col-span-2">
          <div className="panel-header"><h2 className="text-sm font-semibold">Stock Trend</h2></div>
          <div className="p-4">
            {data.stockTrend.length === 0 ? (
              <EmptyState title="No trend data yet" />
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={data.stockTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={{ stroke: "#E5E7EB" }} />
                  <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid #E5E7EB" }} />
                  <Line type="monotone" dataKey="stock" stroke="#0F4C5C" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="panel">
          <div className="panel-header"><h2 className="text-sm font-semibold">Recommendation</h2></div>
          <div className="p-5">
            {data.recommendation ? (
              <div className="rounded-md border border-warning/30 bg-warning-bg p-3">
                <p className="text-sm text-text-primary">{data.recommendation.message}</p>
                <p className="mt-2 text-2xs font-medium uppercase tracking-wider text-warning">
                  Recommended: {data.recommendation.action}
                </p>
              </div>
            ) : (
              <p className="text-sm text-text-secondary">No action recommended — stock levels are within safe thresholds.</p>
            )}
            <div className="mt-4 flex justify-between text-sm">
              <span className="text-text-secondary">Lead Time</span>
              <span className="font-medium tabular-nums">{data.leadTimeDays} days</span>
            </div>
            <div className="mt-2 flex justify-between text-sm">
              <span className="text-text-secondary">Forecasted Demand</span>
              <span className="font-medium tabular-nums">{data.demandForecastUnits} units</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <div className="panel">
          <div className="panel-header"><h2 className="text-sm font-semibold">Recent Transactions</h2></div>
          {data.recentTransactions.length === 0 ? (
            <EmptyState title="No recent transactions" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead><tr><th className="table-th">Type</th><th className="table-th">Qty</th><th className="table-th">Reference</th><th className="table-th">When</th></tr></thead>
                <tbody>
                  {data.recentTransactions.map((t) => (
                    <tr key={t.id}>
                      <td className="table-td">{t.type}</td>
                      <td className="table-td tabular-nums">{t.quantity}</td>
                      <td className="table-td text-text-secondary">{t.reference ?? "—"}</td>
                      <td className="table-td text-text-secondary">{formatRelativeTime(t.timestamp)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="panel">
          <div className="panel-header"><h2 className="text-sm font-semibold">Related Orders</h2></div>
          {data.relatedOrders.length === 0 ? (
            <EmptyState title="No related orders" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead><tr><th className="table-th">Order</th><th className="table-th">Qty</th><th className="table-th">Status</th></tr></thead>
                <tbody>
                  {data.relatedOrders.map((o) => (
                    <tr key={o.id}>
                      <td className="table-td font-medium">{o.id}</td>
                      <td className="table-td tabular-nums">{o.quantity}</td>
                      <td className="table-td"><Badge tone={statusTone(o.status)}>{o.status}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      <p className="text-2xs text-text-secondary">Last updated {formatDate(data.lastUpdated)}</p>
    </div>
  );
}
