import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { AlertTriangle } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Skeleton } from "@/components/common/Skeleton";
import { useProducts } from "@/hooks/useProducts";
import { useCreateOrder, useOrder, useUpdateOrder } from "@/hooks/useOrders";
import type { OrderPriority } from "@/types";

const PRIORITIES: OrderPriority[] = ["Low", "Medium", "High", "Urgent"];

export default function OrderForm() {
  const { id } = useParams();
  const isEdit = !!id;
  const navigate = useNavigate();

  const { data: existing, isLoading: loadingExisting } = useOrder(isEdit ? id : undefined);
  const { data: products, isLoading: loadingProducts } = useProducts();
  const createOrder = useCreateOrder();
  const updateOrder = useUpdateOrder(id ?? "");

  const [customerId, setCustomerId] = useState("");
  const [productId, setProductId] = useState("");
  const [quantity, setQuantity] = useState<number>(0);
  const [requiredDate, setRequiredDate] = useState("");
  const [priority, setPriority] = useState<OrderPriority>("Medium");
  const [notes, setNotes] = useState("");

  useEffect(() => {
    if (existing) {
      setProductId(existing.product.id);
      setQuantity(existing.quantity);
      setRequiredDate(existing.requiredDate.slice(0, 10));
      setPriority(existing.priority);
      setNotes(existing.notes ?? "");
    }
  }, [existing]);

  const selectedProduct = products?.find((p) => p.id === productId);
  const exceedsStock = selectedProduct ? quantity > selectedProduct.availableStock : false;

  const isSubmitting = createOrder.isPending || updateOrder.isPending;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { customerId, productId, quantity, requiredDate, priority, notes };
    if (isEdit) {
      updateOrder.mutate(payload, { onSuccess: () => navigate(`/orders/${id}`) });
    } else {
      createOrder.mutate(payload, { onSuccess: (o) => navigate(`/orders/${o.id}`) });
    }
  };

  if (isEdit && loadingExisting) {
    return <Skeleton className="h-96 w-full" />;
  }

  return (
    <div className="flex flex-col gap-5 max-w-2xl">
      <PageHeader
        title={isEdit ? `Edit Order ${id}` : "Create Order"}
        subtitle={isEdit ? "Update order details below." : "Fill in the details to place a new customer order."}
      />

      <form onSubmit={handleSubmit} className="panel p-5 flex flex-col gap-4">
        <div>
          <label className="label-eyebrow mb-1.5 block">Customer</label>
          <input
            className="input-field"
            placeholder="Customer name or ID"
            value={customerId}
            onChange={(e) => setCustomerId(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="label-eyebrow mb-1.5 block">Product</label>
          <select
            className="input-field"
            value={productId}
            onChange={(e) => setProductId(e.target.value)}
            required
          >
            <option value="">{loadingProducts ? "Loading products…" : "Select a product"}</option>
            {products?.map((p) => (
              <option key={p.id} value={p.id}>{p.code} — {p.name}</option>
            ))}
          </select>
        </div>

        {selectedProduct && (
          <div className="grid grid-cols-2 gap-3 rounded-md border border-border bg-bg p-3 text-sm sm:grid-cols-5">
            <div><p className="text-2xs text-text-secondary">Current Stock</p><p className="font-medium tabular-nums">{selectedProduct.currentStock}</p></div>
            <div><p className="text-2xs text-text-secondary">Reserved</p><p className="font-medium tabular-nums">{selectedProduct.reservedStock}</p></div>
            <div><p className="text-2xs text-text-secondary">Available</p><p className="font-medium tabular-nums">{selectedProduct.availableStock}</p></div>
            <div><p className="text-2xs text-text-secondary">Lead Time</p><p className="font-medium tabular-nums">{selectedProduct.leadTimeDays}d</p></div>
            <div><p className="text-2xs text-text-secondary">Safety Stock</p><p className="font-medium tabular-nums">{selectedProduct.safetyStock}</p></div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label-eyebrow mb-1.5 block">Quantity</label>
            <input
              type="number"
              min={1}
              className="input-field"
              value={quantity || ""}
              onChange={(e) => setQuantity(Number(e.target.value))}
              required
            />
          </div>
          <div>
            <label className="label-eyebrow mb-1.5 block">Required Delivery Date</label>
            <input
              type="date"
              className="input-field"
              value={requiredDate}
              onChange={(e) => setRequiredDate(e.target.value)}
              required
            />
          </div>
        </div>

        {exceedsStock && (
          <div className="flex items-start gap-2 rounded-md border border-warning/30 bg-warning-bg p-3 text-sm text-warning">
            <AlertTriangle size={16} className="mt-0.5 shrink-0" />
            <span>Requested quantity ({quantity}) exceeds available stock ({selectedProduct?.availableStock}). This order may trigger a production request.</span>
          </div>
        )}

        <div>
          <label className="label-eyebrow mb-1.5 block">Priority</label>
          <div className="flex gap-2">
            {PRIORITIES.map((p) => (
              <button
                type="button"
                key={p}
                onClick={() => setPriority(p)}
                className={`rounded-md border px-3 py-1.5 text-sm ${
                  priority === p ? "border-brand bg-brand/10 text-brand font-medium" : "border-border text-text-secondary"
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="label-eyebrow mb-1.5 block">Notes</label>
          <textarea
            className="input-field"
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Optional delivery or handling instructions"
          />
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <button type="button" className="btn-secondary" onClick={() => navigate(-1)}>Cancel</button>
          <button type="submit" className="btn-primary" disabled={isSubmitting}>
            {isSubmitting ? "Saving…" : isEdit ? "Save Changes" : "Create Order"}
          </button>
        </div>
      </form>
    </div>
  );
}
