import { useState } from "react";
import {
  Area, ComposedChart, CartesianGrid, Line, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { PageHeader } from "@/components/common/PageHeader";
import { Skeleton } from "@/components/common/Skeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { EmptyState } from "@/components/common/EmptyState";
import { useProducts } from "@/hooks/useProducts";
import { useForecastByProduct } from "@/hooks/useForecast";
import type { ForecastHorizon } from "@/types";
import { formatNumber } from "@/utils/format";

const HORIZONS: ForecastHorizon[] = [7, 30, 60, 90];

export default function Forecast() {
  const { data: products } = useProducts();
  const [productId, setProductId] = useState<string>("");
  const [horizon, setHorizon] = useState<ForecastHorizon>(30);

  const activeProductId = productId || products?.[0]?.id;
  const { data, isLoading, isError, refetch } = useForecastByProduct(activeProductId, horizon);

  return (
    <div className="flex flex-col gap-5">
      <PageHeader title="Demand Forecast" subtitle="Analyze historical demand and predict future product requirements." />

      <div className="panel p-3 flex flex-wrap items-center gap-2">
        <select className="input-field w-auto" value={activeProductId ?? ""} onChange={(e) => setProductId(e.target.value)}>
          {products?.map((p) => <option key={p.id} value={p.id}>{p.code} — {p.name}</option>)}
        </select>
        <div className="flex rounded-md border border-border overflow-hidden">
          {HORIZONS.map((h) => (
            <button
              key={h}
              onClick={() => setHorizon(h)}
              className={`px-3 py-1.5 text-sm ${horizon === h ? "bg-brand text-white" : "bg-surface text-text-secondary hover:bg-bg"}`}
            >
              {h}D
            </button>
          ))}
        </div>
      </div>

      {isLoading && <Skeleton className="h-96 w-full" />}
      {isError && <ErrorState message="Could not load forecast data." onRetry={() => refetch()} />}
      {!isLoading && !data && <EmptyState title="Select a product to view its forecast" />}

      {data && (
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
          <div className="panel xl:col-span-2">
            <div className="panel-header">
              <h2 className="text-sm font-semibold">{data.product.name} — {horizon}-Day Forecast</h2>
              <div className="flex items-center gap-3 text-2xs text-text-secondary">
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-brand" />Historical</span>
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-accent" />Forecasted</span>
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-accent/20" />Confidence range</span>
              </div>
            </div>
            <div className="p-4">
              {data.series.length === 0 ? (
                <EmptyState title="No forecast series available yet" />
              ) : (
                <ResponsiveContainer width="100%" height={320}>
                  <ComposedChart data={data.series}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
                    <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={{ stroke: "#E5E7EB" }} />
                    <YAxis tick={{ fontSize: 11, fill: "#6B7280" }} tickLine={false} axisLine={false} />
                    <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid #E5E7EB" }} />
                    <Area dataKey="confidenceHigh" stroke="none" fill="#2563EB" fillOpacity={0.08} />
                    <Area dataKey="confidenceLow" stroke="none" fill="#FFFFFF" fillOpacity={1} />
                    <Line type="monotone" dataKey="historicalDemand" stroke="#0F4C5C" strokeWidth={2} dot={false} name="Historical" />
                    <Line type="monotone" dataKey="forecastedDemand" stroke="#2563EB" strokeWidth={2} strokeDasharray="5 4" dot={false} name="Forecasted" />
                  </ComposedChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="panel">
            <div className="panel-header"><h2 className="text-sm font-semibold">Forecast Summary</h2></div>
            <div className="flex flex-col gap-3 p-5 text-sm">
              <Row label="Predicted Demand" value={`${formatNumber(data.summary.predictedDemand)} units`} />
              <Row label="Current Stock" value={`${formatNumber(data.summary.currentStock)} units`} />
              <Row label="Safety Stock" value={`${formatNumber(data.summary.safetyStock)} units`} />
              <Row label="Stock Gap" value={`${formatNumber(data.summary.stockGap)} units`} highlight={data.summary.stockGap > 0} />
              <Row label="Trend" value={data.summary.trend} />
              <Row label="Forecast Model" value={data.summary.model} />
              <Row label="Confidence" value={`${data.summary.confidence}%`} />
            </div>
          </div>
        </div>
      )}

      {data && (
        <div className="panel">
          <div className="panel-header"><h2 className="text-sm font-semibold">Demand Pattern Analysis</h2></div>
          <div className="grid grid-cols-2 gap-4 p-5 sm:grid-cols-3 xl:grid-cols-6">
            <Metric label="Demand Trend" value={data.summary.trend} />
            <Metric label="Growth Rate" value={`${data.summary.growthRate > 0 ? "+" : ""}${data.summary.growthRate}%`} />
            <Metric label="Avg Daily Demand" value={`${formatNumber(data.summary.avgDailyDemand)} u`} />
            <Metric label="Peak Demand" value={`${formatNumber(data.summary.peakDemand)} u`} />
            <Metric label="Volatility" value={data.summary.volatility} />
            <Metric label="Stockout Risk" value={data.summary.stockoutRiskDays ? `${data.summary.stockoutRiskDays}d` : "Low"} />
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex justify-between">
      <span className="text-text-secondary">{label}</span>
      <span className={`font-medium tabular-nums ${highlight ? "text-critical" : "text-text-primary"}`}>{value}</span>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="label-eyebrow mb-1">{label}</p>
      <p className="text-sm font-semibold text-text-primary">{value}</p>
    </div>
  );
}
