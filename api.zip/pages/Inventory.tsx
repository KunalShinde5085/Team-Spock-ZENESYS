import { useState } from "react";
import { Link } from "react-router-dom";
import { Search } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { KpiCard } from "@/components/common/KpiCard";
import { Badge, statusTone } from "@/components/common/Badge";
import { TableSkeleton, KpiSkeleton } from "@/components/common/Skeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { EmptyState } from "@/components/common/EmptyState";
import { useInventoryList } from "@/hooks/useInventory";
import { Boxes, ShieldAlert, TrendingDown, PackageX, Layers } from "lucide-react";
import { formatDate } from "@/utils/format";

export default function Inventory() {
  const [search, setSearch] = useState("");
  const [stockStatus, setStockStatus] = useState("");
  const { data, isLoading, isError, refetch } = useInventoryList({ search: search || undefined, stockStatus: stockStatus || undefined });

  const counts = {
    total: data?.length ?? 0,
    healthy: data?.filter((p) => p.stockStatus === "Healthy").length ?? 0,
    low: data?.filter((p) => p.stockStatus === "Low").length ?? 0,
    critical: data?.filter((p) => p.stockStatus === "Critical").length ?? 0,
    overstock: data?.filter((p) => p.stockStatus === "Overstock").length ?? 0,
  };

  return (
    <div className="flex flex-col gap-5">
      <PageHeader title="Inventory" subtitle="Monitor stock levels and identify inventory risks." />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
        {isLoading
          ? Array.from({ length: 5 }).map((_, i) => <KpiSkeleton key={i} />)
          : (
            <>
              <KpiCard label="Total SKUs" value={String(counts.total)} icon={Layers} />
              <KpiCard label="Healthy Stock" value={String(counts.healthy)} icon={Boxes} tone="success" />
              <KpiCard label="Low Stock" value={String(counts.low)} icon={TrendingDown} tone="warning" />
              <KpiCard label="Critical Stock" value={String(counts.critical)} icon={ShieldAlert} tone="critical" />
              <KpiCard label="Overstock" value={String(counts.overstock)} icon={PackageX} />
            </>
          )}
      </div>

      <div className="panel p-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-text-secondary" />
            <input className="input-field pl-8" placeholder="Search SKU, product name…" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <select className="input-field w-auto" value={stockStatus} onChange={(e) => setStockStatus(e.target.value)}>
            <option value="">All statuses</option>
            <option value="Healthy">Healthy</option>
            <option value="Low">Low</option>
            <option value="Critical">Critical</option>
            <option value="Overstock">Overstock</option>
          </select>
        </div>
      </div>

      <div className="panel overflow-hidden">
        {isLoading && <TableSkeleton rows={8} cols={10} />}
        {isError && <div className="p-4"><ErrorState message="Could not load inventory." onRetry={() => refetch()} /></div>}
        {data && data.length === 0 && <EmptyState title="No inventory items found" description="Adjust your filters or check back once stock data syncs." />}
        {data && data.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-th">Code</th>
                  <th className="table-th">Product</th>
                  <th className="table-th">Category</th>
                  <th className="table-th">Warehouse</th>
                  <th className="table-th">Current</th>
                  <th className="table-th">Reserved</th>
                  <th className="table-th">Available</th>
                  <th className="table-th">Safety</th>
                  <th className="table-th">Reorder Lvl</th>
                  <th className="table-th">Status</th>
                  <th className="table-th">Updated</th>
                </tr>
              </thead>
              <tbody>
                {data.map((p) => (
                  <tr key={p.id} className="hover:bg-bg/60">
                    <td className="table-td"><Link to={`/inventory/${p.id}`} className="font-mono text-xs font-medium text-accent hover:underline">{p.code}</Link></td>
                    <td className="table-td">{p.name}</td>
                    <td className="table-td text-text-secondary">{p.category}</td>
                    <td className="table-td text-text-secondary">{p.warehouse}</td>
                    <td className="table-td tabular-nums">{p.currentStock}</td>
                    <td className="table-td tabular-nums">{p.reservedStock}</td>
                    <td className="table-td tabular-nums font-medium">{p.availableStock}</td>
                    <td className="table-td tabular-nums text-text-secondary">{p.safetyStock}</td>
                    <td className="table-td tabular-nums text-text-secondary">{p.reorderLevel}</td>
                    <td className="table-td"><Badge tone={statusTone(p.stockStatus)}>{p.stockStatus}</Badge></td>
                    <td className="table-td text-text-secondary">{formatDate(p.lastUpdated)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
