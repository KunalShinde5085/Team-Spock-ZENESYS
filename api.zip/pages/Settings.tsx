import { PageHeader } from "@/components/common/PageHeader";
import { SUPABASE_URL } from "@/lib/supabaseClient";

export default function Settings() {
  return (
    <div className="flex flex-col gap-5 max-w-xl">
      <PageHeader title="Settings" subtitle="Platform configuration and connection details." />
      <div className="panel p-5">
        <p className="label-eyebrow mb-1.5">Supabase Project URL</p>
        <p className="font-mono text-sm text-text-primary">{SUPABASE_URL}</p>
        <p className="mt-2 text-2xs text-text-secondary">
          Set via the VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables at build time.
        </p>
      </div>
    </div>
  );
}
