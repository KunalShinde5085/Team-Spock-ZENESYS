import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { CheckCircle2, Circle, PencilLine, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Badge, statusTone } from "@/components/common/Badge";
import { Skeleton } from "@/components/common/Skeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { ConfirmModal } from "@/components/common/ConfirmModal";
import { useDeleteOrder, useOrder } from "@/hooks/useOrders";
import { formatDate } from "@/utils/format";

export default function OrderDetails() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const { data: order, isLoading, isError, refetch } = useOrder(id);
  const deleteOrder = useDeleteOrder();
  const [confirmOpen, setConfirmOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="flex flex-col gap-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }

  if (isError || !order) {
    return <ErrorState message="Could not load this order." onRetry={() => refetch()} />;
  }

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title={order.id}
        subtitle={`Created ${formatDate(order.orderDate)} · Required by ${formatDate(order.requiredDate)}`}
        actions={
          <>
            <Badge tone={statusTone(order.status)}>{order.status}</Badge>
            <Link to={`/orders/${order.id}/edit`} className="btn-secondary">
              <PencilLine size={14} />
              Edit Order
            </Link>
            <button className="btn-danger" onClick={() => setConfirmOpen(true)}>
              <Trash2 size={14} />
              Delete
            </button>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        {/* Left: info + timeline */}
        <div className="flex flex-col gap-4 xl:col-span-2">
          <div className="panel">
            <div className="panel-header"><h2 className="text-sm font-semibold">Customer Information</h2></div>
            <div className="grid grid-cols-2 gap-4 p-5 text-sm sm:grid-cols-3">
              <div><p className="label-eyebrow mb-1">Name</p><p>{order.customer.name}</p></div>
              <div><p className="label-eyebrow mb-1">Company</p><p>{order.customer.company ?? "—"}</p></div>
              <div><p className="label-eyebrow mb-1">Email</p><p>{order.customer.email ?? "—"}</p></div>
            </div>
          </div>

          <div className="panel">
            <div className="panel-header"><h2 className="text-sm font-semibold">Product Information</h2></div>
            <div className="grid grid-cols-2 gap-4 p-5 text-sm sm:grid-cols-3">
              <div><p className="label-eyebrow mb-1">Product</p><p>{order.product.name}</p></div>
              <div><p className="label-eyebrow mb-1">Code</p><p>{order.product.code}</p></div>
              <div><p className="label-eyebrow mb-1">Quantity</p><p className="tabular-nums">{order.quantity} units</p></div>
            </div>
          </div>

          <div className="panel">
            <div className="panel-header"><h2 className="text-sm font-semibold">Order Timeline</h2></div>
            <div className="p-5">
              <ol className="flex flex-col gap-0">
                {order.timeline.map((step, i) => (
                  <li key={step.label} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      {step.status === "completed" ? (
                        <CheckCircle2 size={18} className="text-success" />
                      ) : step.status === "active" ? (
                        <Circle size={18} className="text-accent fill-accent/20" />
                      ) : (
                        <Circle size={18} className="text-gray-300" />
                      )}
                      {i < order.timeline.length - 1 && (
                        <div className={`w-px flex-1 min-h-[24px] ${step.status === "completed" ? "bg-success" : "bg-gray-200"}`} />
                      )}
                    </div>
                    <div className="pb-5">
                      <p className={`text-sm ${step.status === "pending" ? "text-text-secondary" : "font-medium text-text-primary"}`}>
                        {step.label}
                      </p>
                      {step.timestamp && <p className="text-2xs text-text-secondary">{formatDate(step.timestamp)}</p>}
                    </div>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>

        {/* Right: risk panel */}
        <div className="flex flex-col gap-4">
          <div className="panel">
            <div className="panel-header"><h2 className="text-sm font-semibold">Order Risk Panel</h2></div>
            <div className="flex flex-col gap-3 p-5 text-sm">
              <div className="flex justify-between"><span className="text-text-secondary">Inventory Available</span><span className="tabular-nums font-medium">{order.inventoryAvailable}</span></div>
              <div className="flex justify-between"><span className="text-text-secondary">Required</span><span className="tabular-nums font-medium">{order.requiredQuantity}</span></div>
              <div className="flex justify-between"><span className="text-text-secondary">Shortage</span><span className="tabular-nums font-medium text-critical">{order.shortage}</span></div>
              <div className="flex justify-between items-center"><span className="text-text-secondary">Severity</span><Badge tone={statusTone(order.severity)}>{order.severity}</Badge></div>
              {order.recommendedAction && (
                <div className="mt-2 rounded-md bg-warning-bg border border-warning/20 p-3">
                  <p className="label-eyebrow mb-1 text-warning">Recommended Action</p>
                  <p className="text-sm text-text-primary">{order.recommendedAction}</p>
                </div>
              )}
            </div>
          </div>

          {order.notes && (
            <div className="panel">
              <div className="panel-header"><h2 className="text-sm font-semibold">Notes</h2></div>
              <div className="p-5 text-sm text-text-secondary">{order.notes}</div>
            </div>
          )}
        </div>
      </div>

      <ConfirmModal
        open={confirmOpen}
        title="Delete Order?"
        description="This action may affect related operational records and cannot be undone."
        confirmLabel="Delete Order"
        loading={deleteOrder.isPending}
        onCancel={() => setConfirmOpen(false)}
        onConfirm={() => {
          deleteOrder.mutate(order.id, {
            onSuccess: () => navigate("/orders"),
          });
        }}
      />
    </div>
  );
}
