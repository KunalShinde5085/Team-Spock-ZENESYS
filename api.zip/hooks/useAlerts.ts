import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { alertsApi, type AlertFilters } from "@/api/alerts";
import type { AlertStatus } from "@/types";

export function useAlerts(filters: AlertFilters = {}) {
  return useQuery({
    queryKey: ["alerts", filters],
    queryFn: () => alertsApi.list(filters),
  });
}

export function useUpdateAlert() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }: { id: string; status: AlertStatus }) =>
      alertsApi.update(id, { status }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["alerts"] }),
  });
}
