import { useQuery } from "@tanstack/react-query";
import { inventoryApi, type InventoryFilters } from "@/api/inventory";

export function useInventoryList(filters: InventoryFilters = {}) {
  return useQuery({
    queryKey: ["inventory", filters],
    queryFn: () => inventoryApi.list(filters),
  });
}

export function useInventoryDetail(id: string | undefined) {
  return useQuery({
    queryKey: ["inventory-detail", id],
    queryFn: () => inventoryApi.getById(id as string),
    enabled: !!id,
  });
}
