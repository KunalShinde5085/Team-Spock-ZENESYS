import { useQuery } from "@tanstack/react-query";
import { dashboardApi } from "@/api/dashboard";

export function useDashboardKpis() {
  return useQuery({ queryKey: ["dashboard-kpis"], queryFn: dashboardApi.getKpis });
}

export function useFulfillmentBreakdown() {
  return useQuery({
    queryKey: ["fulfillment-breakdown"],
    queryFn: dashboardApi.getFulfillmentBreakdown,
  });
}

export function useInventoryRiskBreakdown() {
  return useQuery({
    queryKey: ["inventory-risk-breakdown"],
    queryFn: dashboardApi.getInventoryRiskBreakdown,
  });
}

export function useDemandVsInventory() {
  return useQuery({
    queryKey: ["demand-vs-inventory"],
    queryFn: dashboardApi.getDemandVsInventory,
  });
}
