import { useQuery } from "@tanstack/react-query";
import { productionApi, type ProductionFilters } from "@/api/production";

export function useProduction(filters: ProductionFilters = {}) {
  return useQuery({
    queryKey: ["production", filters],
    queryFn: () => productionApi.list(filters),
  });
}
