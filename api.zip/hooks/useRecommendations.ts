import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { recommendationsApi } from "@/api/recommendations";
import type { RecommendationStatus } from "@/types";

export function useRecommendations(status?: RecommendationStatus) {
  return useQuery({
    queryKey: ["recommendations", status],
    queryFn: () => recommendationsApi.list(status),
  });
}

export function useUpdateRecommendation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }: { id: string; status: RecommendationStatus }) =>
      recommendationsApi.update(id, { status }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["recommendations"] }),
  });
}
