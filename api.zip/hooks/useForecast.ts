import { useQuery } from "@tanstack/react-query";
import { forecastsApi } from "@/api/forecasts";
import type { ForecastHorizon } from "@/types";

export function useForecastByProduct(productId: string | undefined, horizon: ForecastHorizon) {
  return useQuery({
    queryKey: ["forecast", productId, horizon],
    queryFn: () => forecastsApi.getByProduct(productId as string, horizon),
    enabled: !!productId,
  });
}
