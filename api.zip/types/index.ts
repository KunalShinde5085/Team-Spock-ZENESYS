// ---------- Shared enums ----------

export type OrderStatus =
  | "Pending"
  | "Confirmed"
  | "Processing"
  | "Packed"
  | "Ready to Ship"
  | "Shipped"
  | "In Transit"
  | "Delivered"
  | "Cancelled";

export type OrderPriority = "Low" | "Medium" | "High" | "Urgent";

export type RiskLevel = "Healthy" | "At Risk" | "Delayed" | "Stock Shortage";

export type StockStatus = "Healthy" | "Low" | "Critical" | "Overstock";

export type Severity = "Critical" | "High" | "Medium" | "Low";

export type AlertType =
  | "Stock Shortage"
  | "Low Stock"
  | "Inventory Threshold Breach"
  | "Delayed Order"
  | "Delayed Shipment"
  | "Production Delay"
  | "Stockout Risk";

export type AlertStatus = "Open" | "Acknowledged" | "Resolved" | "Dismissed";

export type RecommendationAction = "PRODUCE" | "PURCHASE" | "TRANSFER" | "HOLD";

export type RecommendationStatus = "Pending" | "Approved" | "Rejected" | "Completed";

export type ForecastHorizon = 7 | 30 | 60 | 90;

// ---------- Core entities ----------

export interface Customer {
  id: string;
  name: string;
  company?: string;
  email?: string;
  phone?: string;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  category: string;
  currentStock: number;
  reservedStock: number;
  damagedStock: number;
  availableStock: number;
  safetyStock: number;
  reorderLevel: number;
  leadTimeDays: number;
  warehouse: string;
  stockStatus: StockStatus;
  lastUpdated: string;
}

export interface Order {
  id: string;
  customer: Customer;
  product: Pick<Product, "id" | "code" | "name">;
  quantity: number;
  orderDate: string;
  requiredDate: string;
  priority: OrderPriority;
  status: OrderStatus;
  risk: RiskLevel;
  notes?: string;
}

export interface OrderTimelineStep {
  label: string;
  status: "completed" | "active" | "pending";
  timestamp?: string;
}

export interface OrderDetail extends Order {
  timeline: OrderTimelineStep[];
  inventoryAvailable: number;
  requiredQuantity: number;
  shortage: number;
  severity: Severity | "NONE";
  recommendedAction?: string;
}

export interface InventoryTransaction {
  id: string;
  type: "Inbound" | "Outbound" | "Adjustment" | "Reserved" | "Released";
  quantity: number;
  reference?: string;
  timestamp: string;
}

export interface InventoryDetail extends Product {
  stockTrend: { date: string; stock: number }[];
  recentTransactions: InventoryTransaction[];
  relatedOrders: Pick<Order, "id" | "status" | "quantity">[];
  demandForecastUnits: number;
  recommendation?: {
    message: string;
    action: string;
  };
}

export interface ProductionRecord {
  id: string;
  product: Pick<Product, "id" | "code" | "name">;
  date: string;
  planned: number;
  produced: number;
  rejected: number;
  efficiency: number;
  status: "Scheduled" | "In Progress" | "Completed" | "Delayed";
}

export interface ForecastPoint {
  period: string;
  historicalDemand?: number;
  forecastedDemand?: number;
  confidenceLow?: number;
  confidenceHigh?: number;
  currentInventory?: number;
}

export interface ForecastSummary {
  productId: string;
  predictedDemand: number;
  currentStock: number;
  safetyStock: number;
  stockGap: number;
  trend: "Increasing" | "Decreasing" | "Stable";
  model: string;
  confidence: number;
  avgDailyDemand: number;
  peakDemand: number;
  growthRate: number;
  volatility: "Low" | "Medium" | "High";
  stockoutRiskDays?: number;
}

export interface Forecast {
  product: Pick<Product, "id" | "code" | "name">;
  horizon: ForecastHorizon;
  series: ForecastPoint[];
  summary: ForecastSummary;
}

export interface Recommendation {
  id: string;
  product: Pick<Product, "id" | "code" | "name">;
  currentStock: number;
  predictedDemand: number;
  safetyStock: number;
  reorderPoint: number;
  recommendedQuantity: number;
  action: RecommendationAction;
  priority: Severity;
  status: RecommendationStatus;
  reason: string;
}

export interface Alert {
  id: string;
  severity: Severity;
  type: AlertType;
  title: string;
  product?: Pick<Product, "id" | "code" | "name">;
  order?: Pick<Order, "id">;
  detectedAt: string;
  status: AlertStatus;
  description?: string;
}

export interface DashboardKpis {
  activeOrders: number;
  activeOrdersDelta: number;
  ordersAtRisk: number;
  inventoryValue: number;
  lowStockItems: number;
  forecastedDemand30d: number;
  openCriticalAlerts: number;
}

export interface FulfillmentBreakdown {
  status: OrderStatus;
  count: number;
}

export interface InventoryRiskBreakdown {
  status: StockStatus;
  count: number;
}

// ---------- API request payloads ----------

export interface CreateOrderPayload {
  customerId: string;
  productId: string;
  quantity: number;
  requiredDate: string;
  priority: OrderPriority;
  notes?: string;
}

export type UpdateOrderPayload = Partial<CreateOrderPayload> & {
  status?: OrderStatus;
};

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface OrderFilters {
  search?: string;
  status?: OrderStatus;
  priority?: OrderPriority;
  customerId?: string;
  productId?: string;
  dateFrom?: string;
  dateTo?: string;
  page?: number;
  pageSize?: number;
}
